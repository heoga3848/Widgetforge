package com.example.widgetforge

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID)
            setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize().systemBarsPadding()) { App(wid) } } }
    }

    fun finishPick(wid: Int, d: Design) {
        Store.assign(this, wid, d.id)
        WidgetForgeProvider.update(this, AppWidgetManager.getInstance(this), wid)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid)); finish()
    }
}

private fun ratio(d: Design): Float = (d.outW / d.outH).coerceIn(0.05f, 20f)

@Composable
fun App(wid: Int) {
    val ctx = LocalContext.current as MainActivity
    val picking = wid != AppWidgetManager.INVALID_APPWIDGET_ID
    var designs by remember { mutableStateOf(Store.list(ctx)) }
    var editing by remember { mutableStateOf<Design?>(null) }
    var report by remember { mutableStateOf<List<String>>(emptyList()) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val results = runCatching { Importer.readAll(ctx, it) }
                .getOrElse { ex -> listOf(ImportResult(null, error = "Error al leer el archivo: ${ex.message}")) }
            val lines = ArrayList<String>()
            for (r in results) {
                val d = r.design
                if (d == null) {
                    lines.add("✗ ${r.error ?: "No se pudo importar"}")
                } else {
                    d.id = UUID.randomUUID().toString(); Store.save(ctx, d)
                    lines.add("✓ ${d.name}")
                    r.notes.forEach { n -> lines.add("   · $n") }
                }
            }
            designs = Store.list(ctx); report = lines
        }
    }
    val e = editing
    if (e != null) { Editor(e) { editing = null; designs = Store.list(ctx) }; return }
    Column(Modifier.padding(12.dp)) {
        Text(if (picking) "Elige un diseño para este widget" else "WidgetForge", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Store.templates().forEach { t -> TextButton({ editing = t }) { Text("+ ${t.name}") } }
            TextButton({ importer.launch(arrayOf("*/*")) }) { Text("Importar (.kwgt / .zip)") }
        }
        if (report.isNotEmpty()) {
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                        report.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                    TextButton({ report = emptyList() }) { Text("Cerrar informe") }
                }
            }
        }
        LazyColumn {
            items(designs, key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        val bmp = remember(d.id, designs) { Renderer.renderFit(ctx, d, 700) }
                        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(ratio(d)))
                        Text(d.name)
                        Row {
                            if (picking) Button({ ctx.finishPick(wid, d) }) { Text("Usar") }
                            TextButton({ editing = d }) { Text("Editar") }
                            TextButton({ Store.delete(ctx, d); designs = Store.list(ctx) }) { Text("Borrar") }
                        }
                    }
                }
            }
        }
    }
}

private val PRESETS = listOf(
    0xFFFFFFFF, 0xE6FFFFFF, 0x80FFFFFF, 0xFF000000, 0xFFFF3B30, 0xFF00F2FF, 0xFFFF00E5, 0xFFFFD60A, 0xFF00FF88, 0xFF3DBFAE, 0x00000000, 0xCC101018
).map { it.toInt() }

@Composable
fun Colors(onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        PRESETS.forEach { c -> Box(Modifier.padding(4.dp).size(36.dp).background(Color(c)).border(1.dp, Color.Gray).clickable { onPick(c) }) }
    }
}

@Composable
fun Sl(label: String, v: Float, range: ClosedFloatingPointRange<Float>, set: (Float) -> Unit) {
    Text("$label: ${v.toInt()}"); Slider(v.coerceIn(range), set, valueRange = range)
}

/** Campo numérico (enteros). Solo llama a [set] cuando el texto es un número válido. */
@Composable
fun Num(label: String, v: Float, set: (Float) -> Unit) {
    var s by remember(v) { mutableStateOf(v.toInt().toString()) }
    OutlinedTextField(
        s, { t -> s = t; t.toFloatOrNull()?.let { n -> set(n) } }, Modifier.fillMaxWidth(),
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun Editor(d: Design, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    var scaleContent by remember { mutableStateOf(true) }
    var lockAll by remember { mutableStateOf(true) }
    var lockLayer by remember { mutableStateOf(false) }
    fun upd(f: () -> Unit) { f(); tick++ }
    val bmp = remember(tick) { Renderer.renderFit(ctx, d, 1200) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let { u -> ctx.contentResolver.openOutputStream(u)?.let { o -> Importer.export(ctx, d, o) } }
    }
    val imgPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u -> d.layers.getOrNull(sel)?.let { x -> upd { x.src = Assets.copyIn(ctx, u, "img") } } }
    }
    val fontPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u -> d.layers.getOrNull(sel)?.let { x -> upd { x.font = Assets.copyIn(ctx, u, "ttf") } } }
    }
    val l = d.layers.getOrNull(sel)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(ratio(d)))
        OutlinedTextField(d.name, { upd { d.name = it } }, Modifier.fillMaxWidth(), label = { Text("Nombre") })
        Row {
            Button({ Store.save(ctx, d); onClose() }) { Text("Guardar") }
            TextButton(onClose) { Text("Salir") }
            TextButton({ exporter.launch("${d.name}.zip") }) { Text("Exportar") }
        }

        // ---------- Tamaño y deformación del widget ----------
        Text("Tamaño del widget", style = MaterialTheme.typography.titleMedium)
        Row {
            Box(Modifier.weight(1f)) { Num("Ancho", d.w) { v -> if (v in 20f..4000f) upd { d.resize(v, d.h, scaleContent) } } }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) { Num("Alto", d.h) { v -> if (v in 20f..4000f) upd { d.resize(d.w, v, scaleContent) } } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(scaleContent, { scaleContent = it }); Text("Escalar el contenido al cambiar el tamaño")
        }
        Sl("Ancho del lienzo", d.w, 50f..2000f) { v -> upd { d.resize(v, d.h, scaleContent) } }
        Sl("Alto del lienzo", d.h, 50f..2000f) { v -> upd { d.resize(d.w, v, scaleContent) } }
        Text("Deformar todo el widget (estirar)", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lockAll, { lockAll = it }); Text("Mantener proporción") }
        Sl("Estirar ancho %", d.sx * 100f, 20f..400f) { v -> upd { d.sx = v / 100f; if (lockAll) d.sy = d.sx } }
        Sl("Estirar alto %", d.sy * 100f, 20f..400f) { v -> upd { d.sy = v / 100f; if (lockAll) d.sx = d.sy } }
        TextButton({ upd { d.sx = 1f; d.sy = 1f } }) { Text("Restablecer deformación") }
        Text("En la pantalla de inicio")
        Row {
            FilterChip(d.fit == 0, { upd { d.fit = 0 } }, { Text("Ajustar (proporcional)") })
            Spacer(Modifier.width(8.dp))
            FilterChip(d.fit == 1, { upd { d.fit = 1 } }, { Text("Deformar para llenar") })
        }
        Text("Fondo"); Colors { c -> upd { d.bg = c } }
        Sl("Esquinas del fondo", d.radius, 0f..400f) { upd { d.radius = it } }

        // ---------- Capas ----------
        Text("Capas", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            d.layers.forEachIndexed { i, x -> FilterChip(sel == i, { sel = i }, { Text("${i + 1} ${x.type}") }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf(
                "text" to "+Texto", "rect" to "+Rect", "circle" to "+Círculo", "triangle" to "+Triángulo",
                "arc" to "+Arco", "bar" to "+Barra", "calendar" to "+Calendario", "image" to "+Imagen"
            ).forEach { (t, n) ->
                TextButton({
                    upd {
                        d.layers.add(
                            when (t) {
                                "image" -> Layer(type = t, w = 120f, h = 120f, radius = 24f)
                                "calendar" -> Layer(type = t, w = 260f, h = 190f, size = 14f, color2 = 0xFF3DBFAE.toInt())
                                "bar" -> Layer(type = t, w = 240f, h = 24f, radius = 12f, progress = "battery")
                                else -> Layer(type = t, w = if (t == "text") 0f else 100f, h = 100f)
                            }
                        )
                        sel = d.layers.lastIndex
                    }
                    if (t == "image") imgPick.launch(arrayOf("image/*"))
                }) { Text(n) }
            }
        }
        if (l != null) {
            val t = l.type
            val fillable = t == "text" || t == "rect" || t == "circle" || t == "triangle"
            if (t == "text") {
                OutlinedTextField(
                    l.text, { upd { l.text = it } }, Modifier.fillMaxWidth(),
                    label = { Text("Texto ({hh} {mm} {day} {date} {battery} o fórmulas Kustom \$df(HH:mm)\$)") }
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(l.bold, { upd { l.bold = it } }); Text("Negrita")
                    TextButton({ upd { l.align = 0 } }) { Text("Izq") }
                    TextButton({ upd { l.align = 1 } }) { Text("Centro") }
                    TextButton({ upd { l.align = 2 } }) { Text("Der") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Normal", "MAYÚS", "minús", "Título").forEachIndexed { i, n ->
                        FilterChip(l.textCase == i, { upd { l.textCase = i } }, { Text(n) })
                    }
                }
                Sl("Tamaño", l.size, 8f..800f) { upd { l.size = it } }
                Sl("Ancho de caja (para centrar/alinear)", l.w, 0f..maxOf(d.w, l.w)) { upd { l.w = it } }
                Row {
                    TextButton({ fontPick.launch(arrayOf("*/*")) }) { Text(if (l.font.isEmpty()) "Fuente (.ttf/.otf)…" else "Fuente ✓") }
                    TextButton({
                        upd {
                            l.color = 0xE6FFFFFF.toInt(); l.color2 = 0x66C8C8C8; l.grad = true
                            l.stroke = 1.5f; l.strokeColor = 0x99FFFFFF.toInt(); l.shadow = 6f; l.shColor = 0x55000000
                        }
                    }) { Text("Estilo cristal") }
                }
            }
            if (t != "text") {
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(lockLayer, { lockLayer = it }); Text("Mantener proporción de la capa") }
                Sl("Ancho", l.w, 0f..maxOf(d.w * 2f, l.w)) { v -> upd { if (lockLayer && l.w > 0f) l.h = l.h * v / l.w; l.w = v } }
                Sl("Alto", l.h, 0f..maxOf(d.h * 2f, l.h)) { v -> upd { if (lockLayer && l.h > 0f) l.w = l.w * v / l.h; l.h = v } }
                Row {
                    Box(Modifier.weight(1f)) { Num("Ancho (px)", l.w) { v -> upd { if (lockLayer && l.w > 0f) l.h = l.h * v / l.w; l.w = v } } }
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) { Num("Alto (px)", l.h) { v -> upd { if (lockLayer && l.h > 0f) l.w = l.w * v / l.h; l.h = v } } }
                }
            }
            if (t == "rect" || t == "image" || t == "bar") Sl("Esquinas", l.radius, 0f..300f) { upd { l.radius = it } }
            if (t == "image") TextButton({ imgPick.launch(arrayOf("image/*")) }) { Text(if (l.src.isEmpty()) "Elegir imagen…" else "Cambiar imagen") }
            if (t == "arc" || t == "bar") {
                OutlinedTextField(
                    l.progress, { upd { l.progress = it } }, Modifier.fillMaxWidth(),
                    label = { Text("Progreso: battery, minute, hour, storage, un número 0-100 o \$bi(level)\$") }
                )
            }
            if (t == "arc") Sl("Grosor", l.size, 4f..80f) { upd { l.size = it } }
            if (t == "calendar") Sl("Tamaño del texto", l.size, 6f..40f) { upd { l.size = it } }

            Text("Posición", style = MaterialTheme.typography.titleMedium)
            Row {
                Box(Modifier.weight(1f)) { Num("X", l.x) { v -> upd { l.x = v } } }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) { Num("Y", l.y) { v -> upd { l.y = v } } }
            }
            Sl("X", l.x, (-d.w)..maxOf(d.w * 1.5f, l.x)) { upd { l.x = it } }
            Sl("Y", l.y, (-d.h)..maxOf(d.h * 1.5f, l.y)) { upd { l.y = it } }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton({
                    upd { if (t == "text") { l.x = 0f; l.w = d.w; l.align = 1 } else l.x = (d.w - l.w) / 2f }
                }) { Text("Centrar horizontal") }
                TextButton({
                    upd { l.y = if (t == "text") (d.h - l.size * 1.2f * l.text.split("\n").size) / 2f else (d.h - l.h) / 2f }
                }) { Text("Centrar vertical") }
                if (t != "text") TextButton({ upd { l.x = 0f; l.y = 0f; l.w = d.w; l.h = d.h } }) { Text("Llenar lienzo") }
            }

            Text("Deformar capa", style = MaterialTheme.typography.titleMedium)
            Sl("Estirar ancho %", l.sx * 100f, 10f..400f) { v -> upd { l.sx = v / 100f } }
            Sl("Estirar alto %", l.sy * 100f, 10f..400f) { v -> upd { l.sy = v / 100f } }
            Sl("Inclinación °", l.skew, -45f..45f) { upd { l.skew = it } }
            Sl("Rotación", l.rot, -180f..180f) { upd { l.rot = it } }
            TextButton({ upd { l.sx = 1f; l.sy = 1f; l.skew = 0f; l.rot = 0f } }) { Text("Restablecer deformación de la capa") }

            Text(if (t == "calendar") "Color del texto" else "Color"); Colors { c -> upd { l.color = c } }
            var hex by remember(sel) { mutableStateOf("") }
            OutlinedTextField(hex, { v ->
                hex = v
                runCatching { android.graphics.Color.parseColor(v) }.onSuccess { c -> upd { l.color = c } }
            }, Modifier.fillMaxWidth(), label = { Text("Color #RRGGBB o #AARRGGBB") })
            Sl("Opacidad %", (l.color ushr 24) / 2.55f, 0f..100f) { v -> upd { l.color = (l.color and 0xFFFFFF) or ((v * 2.55f).toInt() shl 24) } }
            if (fillable) {
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(l.grad, { upd { l.grad = it } }); Text("Degradado vertical (2º color abajo)") }
                if (l.grad) Colors { c -> upd { l.color2 = c } }
                Sl("Sombra", l.shadow, 0f..30f) { upd { l.shadow = it } }
            }
            if (t == "calendar") { Text("Color del día de hoy"); Colors { c -> upd { l.color2 = c } } }
            if (fillable || t == "image") {
                Sl("Borde", l.stroke, 0f..20f) { upd { l.stroke = it } }
                if (l.stroke > 0) Colors { c -> upd { l.strokeColor = c } }
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton({ if (sel > 0) upd { d.layers.add(sel - 1, d.layers.removeAt(sel)); sel-- } }) { Text("Subir") }
                TextButton({ if (sel < d.layers.lastIndex) upd { d.layers.add(sel + 1, d.layers.removeAt(sel)); sel++ } }) { Text("Bajar") }
                TextButton({ upd { d.layers.add(sel + 1, l.copy()); sel++ } }) { Text("Duplicar") }
                TextButton({ upd { d.layers.removeAt(sel); sel = 0 } }) { Text("Borrar capa") }
            }
        }
    }
}
