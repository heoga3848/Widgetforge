package com.example.widgetforge

import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Layer(
    var type: String = "text", var text: String = "Texto",
    var x: Float = 20f, var y: Float = 20f, var w: Float = 200f, var h: Float = 60f,
    var color: Int = -1, var size: Float = 32f, var radius: Float = 24f,
    var bold: Boolean = false, var progress: String = "battery",
    var rot: Float = 0f, var shadow: Float = 0f, var shColor: Int = 0x66000000,
    var stroke: Float = 0f, var strokeColor: Int = 0x99FFFFFF.toInt(), var color2: Int = 0xFF888888.toInt(),
    var grad: Boolean = false, var align: Int = 0, var font: String = "", var src: String = ""
) {
    fun toJson() = JSONObject().put("type", type).put("text", text).put("x", x.toDouble()).put("y", y.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble()).put("color", color).put("size", size.toDouble())
        .put("radius", radius.toDouble()).put("bold", bold).put("progress", progress)
        .put("rot", rot.toDouble()).put("shadow", shadow.toDouble()).put("shColor", shColor)
        .put("stroke", stroke.toDouble()).put("strokeColor", strokeColor).put("color2", color2)
        .put("grad", grad).put("align", align).put("font", font).put("src", src)

    companion object {
        fun from(o: JSONObject) = Layer(
            o.optString("type", "text"), o.optString("text", ""),
            o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat(),
            o.optDouble("w", 100.0).toFloat(), o.optDouble("h", 100.0).toFloat(),
            o.optInt("color", -1), o.optDouble("size", 32.0).toFloat(), o.optDouble("radius", 0.0).toFloat(),
            o.optBoolean("bold", false), o.optString("progress", "battery"),
            o.optDouble("rot", 0.0).toFloat(), o.optDouble("shadow", 0.0).toFloat(), o.optInt("shColor", 0x66000000),
            o.optDouble("stroke", 0.0).toFloat(), o.optInt("strokeColor", 0x99FFFFFF.toInt()), o.optInt("color2", 0xFF888888.toInt()),
            o.optBoolean("grad", false), o.optInt("align", 0), o.optString("font", ""), o.optString("src", "")
        )
    }
}

class Design(
    var id: String = UUID.randomUUID().toString(), var name: String = "Nuevo widget",
    var w: Float = 400f, var h: Float = 200f, var bg: Int = 0xCC101018.toInt(), var radius: Float = 36f
) {
    val layers = mutableListOf<Layer>()

    fun toJson() = JSONObject().put("id", id).put("name", name).put("w", w.toDouble()).put("h", h.toDouble())
        .put("bg", bg).put("radius", radius.toDouble()).put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })

    companion object {
        fun from(o: JSONObject): Design {
            val d = Design(
                o.optString("id", UUID.randomUUID().toString()), o.optString("name", "Widget"),
                o.optDouble("w", 400.0).toFloat(), o.optDouble("h", 200.0).toFloat(),
                o.optInt("bg", 0xCC101018.toInt()), o.optDouble("radius", 36.0).toFloat()
            )
            val a = o.optJSONArray("layers") ?: JSONArray()
            for (i in 0 until a.length()) d.layers.add(Layer.from(a.getJSONObject(i)))
            return d
        }
    }
}

object Vars {
    private val kx = Regex("\\\$([^\$]*)\\\$")
    private val vx = Regex("\\{(\\w+)(?::([^}]*))?\\}")
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.getDefault()).format(Date())

    fun battery(c: Context) = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    fun num(c: Context, k: String): Float = when (k) {
        "battery" -> battery(c) / 100f
        "minute" -> Calendar.getInstance().get(Calendar.MINUTE) / 60f
        "hour" -> Calendar.getInstance().get(Calendar.HOUR_OF_DAY) / 24f
        "storage" -> StatFs(Environment.getDataDirectory().path).let { it.availableBytes.toFloat() / it.totalBytes }
        else -> 0f
    }

    private fun days(s: String): String = runCatching {
        val t = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)!!.time
        Math.ceil((t - System.currentTimeMillis()) / 86400000.0).toInt().toString()
    }.getOrDefault("?")

    // Soporte básico de fórmulas estilo KWGT: df(...) tf(...) bi(level)
    private fun kustom(c: Context, e: String): String {
        val m = Regex("(\\w+)\\((.*)\\)").matchEntire(e.trim()) ?: return e.trim().trim('"')
        val a = m.groupValues[2].trim().trim('"')
        return when (m.groupValues[1]) {
            "df", "tf" -> runCatching { fmt(a) }.getOrDefault(a)
            "bi" -> if (a == "level") battery(c).toString() else ""
            else -> ""
        }
    }

    // Variables: {time} {hh} {mm} {ss} {date} {day} {month} {battery} {storage} {days:2026-12-25}
    fun resolve(c: Context, s: String): String {
        val t = kx.replace(s) { kustom(c, it.groupValues[1]) }
        return vx.replace(t) { m ->
            when (m.groupValues[1]) {
                "time" -> fmt("HH:mm"); "hh" -> fmt("HH"); "mm" -> fmt("mm"); "ss" -> fmt("ss")
                "date" -> fmt("dd/MM/yyyy"); "day" -> fmt("EEEE"); "month" -> fmt("MMMM")
                "battery" -> battery(c).toString()
                "storage" -> (num(c, "storage") * 100).toInt().toString()
                "days" -> days(m.groupValues[2])
                else -> m.value
            }
        }
    }
}

object Store {
    private fun dir(c: Context) = File(c.filesDir, "designs").apply { mkdirs() }
    private fun prefs(c: Context) = c.getSharedPreferences("map", 0)

    fun list(c: Context): List<Design> = dir(c).listFiles()
        ?.mapNotNull { f -> runCatching { Design.from(JSONObject(f.readText())) }.getOrNull() }
        ?.sortedBy { it.name } ?: emptyList()

    fun save(c: Context, d: Design) {
        File(dir(c), "${d.id}.json").writeText(d.toJson().toString()); WidgetForgeProvider.refreshAll(c)
    }

    fun delete(c: Context, d: Design) { File(dir(c), "${d.id}.json").delete() }
    fun assign(c: Context, wid: Int, id: String) = prefs(c).edit().putString(wid.toString(), id).apply()
    fun unassign(c: Context, wid: Int) = prefs(c).edit().remove(wid.toString()).apply()
    fun designFor(c: Context, wid: Int): Design? =
        prefs(c).getString(wid.toString(), null)?.let { id -> list(c).firstOrNull { it.id == id } }

    fun templates() = listOf(
        Design(name = "Reloj cristal", bg = 0, radius = 0f).also { d ->
            d.layers += Layer(type = "text", text = "{hh}:{mm}", x = 20f, y = 20f, w = 360f, size = 120f, align = 1, bold = true,
                color = 0xE6FFFFFF.toInt(), color2 = 0x66C8C8C8, grad = true, stroke = 1.5f, strokeColor = 0x99FFFFFF.toInt(), shadow = 6f, shColor = 0x55000000)
            d.layers += Layer(type = "text", text = "{day}, {date}", x = 20f, y = 150f, w = 360f, size = 24f, align = 1, color = 0xCCFFFFFF.toInt())
        },
        Design(name = "Calendario", w = 300f, h = 260f, bg = 0xAAD6F3EE.toInt(), radius = 28f).also { d ->
            d.layers += Layer(type = "text", text = "{month}", x = 20f, y = 12f, size = 22f, bold = true, color = 0xFF2B6F66.toInt())
            d.layers += Layer(type = "calendar", x = 14f, y = 48f, w = 272f, h = 196f, size = 14f, color = 0xFF2B6F66.toInt(), color2 = 0xFF3DBFAE.toInt())
        },
        Design(name = "Reloj", w = 400f, h = 200f).also { d ->
            d.layers += Layer("text", "{hh}:{mm}", 24f, 16f, 0f, 0f, -1, 96f, 0f, true)
            d.layers += Layer("text", "{day}  {date}", 28f, 128f, 0f, 0f, 0xFF00F2FF.toInt(), 26f)
        },
        Design(name = "Anillo de batería", w = 300f, h = 300f, radius = 150f).also { d ->
            d.layers += Layer("arc", "", 30f, 30f, 240f, 240f, 0xFF00FF88.toInt(), 24f, 0f, false, "battery")
            d.layers += Layer(type = "text", text = "{battery}", x = 30f, y = 105f, w = 240f, size = 80f, bold = true, align = 1)
        }
    )
}
