package com.animevault.app.presentation.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.animevault.app.domain.model.Anime
import com.animevault.app.domain.model.ListEntry
import com.animevault.app.domain.model.ListStatus
import com.animevault.app.presentation.components.CenterLoading
import com.animevault.app.presentation.components.NoticeCard
import com.animevault.app.presentation.components.ScoreChip

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailScreen(vm: DetailViewModel, onBack: () -> Unit, onOpenSettings: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val entry by vm.entry.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var showDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.messages.collect { m ->
            val r = snackbar.showSnackbar(m.text, actionLabel = if (m.goSettings) "Ajustes" else null)
            if (r == SnackbarResult.ActionPerformed) onOpenSettings()
        }
    }

    Box(Modifier.fillMaxSize()) {
        when (val s = state) {
            DetailUiState.Loading -> CenterLoading()
            DetailUiState.NotConfigured -> Column(Modifier.padding(16.dp).padding(top = 56.dp)) {
                NoticeCard("Configura tu API de Contenido en Ajustes", actionLabel = "Ir a Ajustes", onAction = onOpenSettings)
            }
            is DetailUiState.Error -> Column(Modifier.padding(16.dp).padding(top = 56.dp)) {
                NoticeCard(s.message, isError = true, actionLabel = "Reintentar", onAction = vm::load)
            }
            is DetailUiState.Success -> DetailContent(
                anime = s.anime,
                entry = entry,
                onSaveClick = { showDialog = true },
                onFavorite = vm::toggleFavorite,
                onDownload = vm::download
            )
        }
        IconButton(
            onClick = onBack,
            modifier = Modifier.padding(8.dp).background(Color(0x66000000), CircleShape)
        ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Volver", tint = Color.White) }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Guardar en Mi Lista") },
            text = {
                Column {
                    ListStatus.entries.forEach { st ->
                        TextButton(onClick = { vm.setStatus(st); showDialog = false }, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                if (entry?.status == st) "✓ ${st.label}" else st.label,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    TextButton(onClick = { vm.setStatus(null); showDialog = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Quitar estado", color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cerrar") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailContent(
    anime: Anime,
    entry: ListEntry?,
    onSaveClick: () -> Unit,
    onFavorite: () -> Unit,
    onDownload: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(420.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
            AsyncImage(
                model = anime.coverUrl,
                contentDescription = anime.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(colorStops = arrayOf(0.4f to Color.Transparent, 1f to MaterialTheme.colorScheme.background))
                )
            )
            Text(
                anime.title,
                modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold
            )
        }
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                anime.score?.let { ScoreChip(it) }
                anime.episodes?.let {
                    Text(
                        "$it episodios",
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            if (anime.genres.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    anime.genres.forEach {
                        Text(
                            it,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = onSaveClick, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Bookmark, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(entry?.status?.let { "Mi Lista · ${it.label}" } ?: "Guardar en Mi Lista", maxLines = 1)
                }
                FilledTonalIconButton(onClick = onFavorite) {
                    Icon(
                        if (entry?.favorite == true) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        "Favorito",
                        tint = if (entry?.favorite == true) MaterialTheme.colorScheme.primary else LocalContentColor.current
                    )
                }
            }
            Button(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Download, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Descargar")
            }
            Text("Sinopsis", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                anime.synopsis ?: "Sin sinopsis disponible.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
