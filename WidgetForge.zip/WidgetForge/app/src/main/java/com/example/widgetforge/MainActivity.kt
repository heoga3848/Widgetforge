package com.example.widgetforge

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID)
            setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize().systemBarsPadding()) { App(wid) } } }
    }

    fun finishPick(wid: Int, d: Design) {
        Store.assign(this, wid, d.id)
        WidgetForgeProvider.update(this, AppWidgetManager.getInstance(this), wid)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid)); finish()
    }
}

@Composable
fun App(wid: Int) {
    val ctx = LocalContext.current as MainActivity
    val picking = wid != AppWidgetManager.INVALID_APPWIDGET_ID
    var designs by remember { mutableStateOf(Store.list(ctx)) }
    var editing by remember { mutableStateOf<Design?>(null) }
    var msg by remember { mutableStateOf("") }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val d = runCatching { Importer.read(ctx, it) }.getOrNull()
            if (d == null) msg = "No se pudo importar el archivo" else {
                d.id = UUID.randomUUID().toString(); Store.save(ctx, d); designs = Store.list(ctx)
                msg = "Importado: ${d.name} (${d.layers.size} capas)"
            }
        }
    }
    val e = editing
    if (e != null) { Editor(e) { editing = null; designs = Store.list(ctx) }; return }
    Column(Modifier.padding(12.dp)) {
        Text(if (picking) "Elige un diseño para este widget" else "WidgetForge", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Store.templates().forEach { t -> TextButton({ editing = t }) { Text("+ ${t.name}") } }
            TextButton({ importer.launch(arrayOf("*/*")) }) { Text("Importar (.kwgt / .zip)") }
        }
        if (msg.isNotEmpty()) Text(msg)
        LazyColumn {
            items(designs, key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        val bmp = remember(d.id, designs) { Renderer.render(ctx, d, 1f) }
                        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(d.w / d.h))
                        Text(d.name)
                        Row {
                            if (picking) Button({ ctx.finishPick(wid, d) }) { Text("Usar") }
                            TextButton({ editing = d }) { Text("Editar") }
                            TextButton({ Store.delete(ctx, d); designs = Store.list(ctx) }) { Text("Borrar") }
                        }
                    }
                }
            }
        }
    }
}

private val PRESETS = listOf(
    0xFFFFFFFF, 0xE6FFFFFF, 0x80FFFFFF, 0xFF000000, 0xFFFF3B30, 0xFF00F2FF, 0xFFFF00E5, 0xFFFFD60A, 0xFF00FF88, 0xFF3DBFAE, 0x00000000, 0xCC101018
).map { it.toInt() }

@Composable
fun Colors(onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        PRESETS.forEach { c -> Box(Modifier.padding(4.dp).size(36.dp).background(Color(c)).border(1.dp, Color.Gray).clickable { onPick(c) }) }
    }
}

@Composable
fun Sl(label: String, v: Float, range: ClosedFloatingPointRange<Float>, set: (Float) -> Unit) {
    Text("$label: ${v.toInt()}"); Slider(v.coerceIn(range), set, valueRange = range)
}

@Composable
fun Editor(d: Design, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    fun upd(f: () -> Unit) { f(); tick++ }
    val bmp = remember(tick) { Renderer.render(ctx, d, 1.5f) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let { u -> ctx.contentResolver.openOutputStream(u)?.let { o -> Importer.export(ctx, d, o) } }
    }
    val imgPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u -> d.layers.getOrNull(sel)?.let { x -> upd { x.src = Assets.copyIn(ctx, u, "img") } } }
    }
    val fontPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u -> d.layers.getOrNull(sel)?.let { x -> upd { x.font = Assets.copyIn(ctx, u, "ttf") } } }
    }
    val l = d.layers.getOrNull(sel)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(d.w / d.h))
        OutlinedTextField(d.name, { upd { d.name = it } }, Modifier.fillMaxWidth(), label = { Text("Nombre") })
        Row {
            Button({ Store.save(ctx, d); onClose() }) { Text("Guardar") }
            TextButton(onClose) { Text("Salir") }
            TextButton({ exporter.launch("${d.name}.zip") }) { Text("Exportar") }
        }
        Sl("Ancho del lienzo", d.w, 100f..800f) { upd { d.w = it } }
        Sl("Alto del lienzo", d.h, 50f..800f) { upd { d.h = it } }
        Text("Fondo"); Colors { c -> upd { d.bg = c } }
        Sl("Esquinas del fondo", d.radius, 0f..400f) { upd { d.radius = it } }
        Text("Capas")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            d.layers.forEachIndexed { i, x -> FilterChip(sel == i, { sel = i }, { Text("${i + 1} ${x.type}") }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("text" to "+Texto", "rect" to "+Rect", "circle" to "+Círculo", "arc" to "+Arco", "calendar" to "+Calendario", "image" to "+Imagen").forEach { (t, n) ->
                TextButton({
                    upd {
                        d.layers.add(
                            when (t) {
                                "image" -> Layer(type = t, w = 120f, h = 120f, radius = 24f)
                                "calendar" -> Layer(type = t, w = 260f, h = 190f, size = 14f, color2 = 0xFF3DBFAE.toInt())
                                else -> Layer(type = t, w = if (t == "text") 0f else 100f, h = 100f)
                            }
                        )
                        sel = d.layers.lastIndex
                    }
                    if (t == "image") imgPick.launch(arrayOf("image/*"))
                }) { Text(n) }
            }
        }
        if (l != null) {
            val t = l.type
            val fillable = t == "text" || t == "rect" || t == "circle"
            if (t == "text") {
                OutlinedTextField(l.text, { upd { l.text = it } }, Modifier.fillMaxWidth(), label = { Text("Texto ({hh} {mm} {day} {date} {battery} {days:2026-12-25})") })
                Row {
                    Checkbox(l.bold, { upd { l.bold = it } }); Text("Negrita")
                    TextButton({ upd { l.align = 0 } }) { Text("Izq") }
                    TextButton({ upd { l.align = 1 } }) { Text("Centro") }
                    TextButton({ upd { l.align = 2 } }) { Text("Der") }
                }
                Sl("Tamaño", l.size, 8f..800f) { upd { l.size = it } }
                Sl("Ancho de caja (para centrar/alinear)", l.w, 0f..d.w) { upd { l.w = it } }
                Row {
                    TextButton({ fontPick.launch(arrayOf("*/*")) }) { Text(if (l.font.isEmpty()) "Fuente (.ttf/.otf)…" else "Fuente ✓") }
                    TextButton({
                        upd {
                            l.color = 0xE6FFFFFF.toInt(); l.color2 = 0x66C8C8C8; l.grad = true
                            l.stroke = 1.5f; l.strokeColor = 0x99FFFFFF.toInt(); l.shadow = 6f; l.shColor = 0x55000000
                        }
                    }) { Text("Estilo cristal") }
                }
            }
            if (t != "text") {
                Sl("Ancho", l.w, 0f..d.w) { upd { l.w = it } }
                Sl("Alto", l.h, 0f..d.h) { upd { l.h = it } }
            }
            if (t == "rect" || t == "image") Sl("Esquinas", l.radius, 0f..300f) { upd { l.radius = it } }
            if (t == "image") TextButton({ imgPick.launch(arrayOf("image/*")) }) { Text(if (l.src.isEmpty()) "Elegir imagen…" else "Cambiar imagen") }
            if (t == "arc") {
                OutlinedTextField(l.progress, { upd { l.progress = it } }, Modifier.fillMaxWidth(), label = { Text("Progreso: battery, minute, hour, storage") })
                Sl("Grosor", l.size, 4f..80f) { upd { l.size = it } }
            }
            if (t == "calendar") Sl("Tamaño del texto", l.size, 6f..40f) { upd { l.size = it } }
            Sl("X", l.x, 0f..d.w) { upd { l.x = it } }
            Sl("Y", l.y, 0f..d.h) { upd { l.y = it } }
            Sl("Rotación", l.rot, -180f..180f) { upd { l.rot = it } }
            Text(if (t == "calendar") "Color del texto" else "Color"); Colors { c -> upd { l.color = c } }
            var hex by remember(sel) { mutableStateOf("") }
            OutlinedTextField(hex, { v ->
                hex = v
                runCatching { android.graphics.Color.parseColor(v) }.onSuccess { c -> upd { l.color = c } }
            }, Modifier.fillMaxWidth(), label = { Text("Color #RRGGBB o #AARRGGBB") })
            Sl("Opacidad %", (l.color ushr 24) / 2.55f, 0f..100f) { v -> upd { l.color = (l.color and 0xFFFFFF) or ((v * 2.55f).toInt() shl 24) } }
            if (fillable) {
                Row { Checkbox(l.grad, { upd { l.grad = it } }); Text("Degradado vertical (2º color abajo)") }
                if (l.grad) Colors { c -> upd { l.color2 = c } }
                Sl("Sombra", l.shadow, 0f..30f) { upd { l.shadow = it } }
            }
            if (t == "calendar") { Text("Color del día de hoy"); Colors { c -> upd { l.color2 = c } } }
            if (fillable || t == "image") {
                Sl("Borde", l.stroke, 0f..20f) { upd { l.stroke = it } }
                if (l.stroke > 0) Colors { c -> upd { l.strokeColor = c } }
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton({ if (sel > 0) upd { d.layers.add(sel - 1, d.layers.removeAt(sel)); sel-- } }) { Text("Subir") }
                TextButton({ if (sel < d.layers.lastIndex) upd { d.layers.add(sel + 1, d.layers.removeAt(sel)); sel++ } }) { Text("Bajar") }
                TextButton({ upd { d.layers.add(sel + 1, l.copy()); sel++ } }) { Text("Duplicar") }
                TextButton({ upd { d.layers.removeAt(sel); sel = 0 } }) { Text("Borrar capa") }
            }
        }
    }
}
