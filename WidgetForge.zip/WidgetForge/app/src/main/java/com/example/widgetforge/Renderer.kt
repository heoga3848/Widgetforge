package com.example.widgetforge

import android.content.Context
import android.graphics.*

object Renderer {
    fun render(c: Context, d: Design, scale: Float = 2f): Bitmap {
        val bmp = Bitmap.createBitmap((d.w * scale).toInt(), (d.h * scale).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = d.bg
        cv.drawRoundRect(RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()), d.radius * scale, d.radius * scale, p)
        for (l in d.layers) {
            p.reset(); p.isAntiAlias = true; p.color = l.color
            val r = RectF(l.x * scale, l.y * scale, (l.x + l.w) * scale, (l.y + l.h) * scale)
            when (l.type) {
                "text" -> {
                    p.textSize = l.size * scale; p.isFakeBoldText = l.bold
                    cv.drawText(Vars.resolve(c, l.text), r.left, r.top + l.size * scale, p)
                }
                "rect" -> cv.drawRoundRect(r, l.radius * scale, l.radius * scale, p)
                "circle" -> cv.drawOval(r, p)
                "arc" -> {
                    p.style = Paint.Style.STROKE; p.strokeWidth = l.size * scale; p.strokeCap = Paint.Cap.ROUND
                    val i = l.size * scale / 2; r.inset(i, i)
                    p.alpha = 50; cv.drawArc(r, 0f, 360f, false, p)
                    p.alpha = 255; cv.drawArc(r, -90f, 360f * Vars.num(c, l.progress), false, p)
                }
            }
        }
        return bmp
    }
}
