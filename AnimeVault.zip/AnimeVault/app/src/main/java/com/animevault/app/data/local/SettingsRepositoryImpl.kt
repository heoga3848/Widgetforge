package com.animevault.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.animevault.app.domain.model.ContentConfig
import com.animevault.app.domain.model.DownloadConfig
import com.animevault.app.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "settings")

class SettingsRepositoryImpl(private val context: Context) : SettingsRepository {

    private object Keys {
        val cBase = stringPreferencesKey("content_base_url")
        val cKey = stringPreferencesKey("content_api_key")
        val cSearch = stringPreferencesKey("content_search_endpoint")
        val cDetail = stringPreferencesKey("content_detail_endpoint")
        val dBase = stringPreferencesKey("download_base_url")
        val dKey = stringPreferencesKey("download_api_key")
        val dEndpoint = stringPreferencesKey("download_endpoint")
    }

    override val contentConfig: Flow<ContentConfig> = context.settingsStore.data.map { p ->
        ContentConfig(
            baseUrl = p[Keys.cBase].orEmpty(),
            apiKey = p[Keys.cKey].orEmpty(),
            searchEndpoint = p[Keys.cSearch].orEmpty(),
            detailEndpoint = p[Keys.cDetail].orEmpty()
        )
    }

    override val downloadConfig: Flow<DownloadConfig> = context.settingsStore.data.map { p ->
        DownloadConfig(
            baseUrl = p[Keys.dBase].orEmpty(),
            apiKey = p[Keys.dKey].orEmpty(),
            downloadEndpoint = p[Keys.dEndpoint].orEmpty()
        )
    }

    override suspend fun saveContent(config: ContentConfig) {
        context.settingsStore.edit { p ->
            p[Keys.cBase] = config.baseUrl.trim()
            p[Keys.cKey] = config.apiKey.trim()
            p[Keys.cSearch] = config.searchEndpoint.trim()
            p[Keys.cDetail] = config.detailEndpoint.trim()
        }
    }

    override suspend fun saveDownload(config: DownloadConfig) {
        context.settingsStore.edit { p ->
            p[Keys.dBase] = config.baseUrl.trim()
            p[Keys.dKey] = config.apiKey.trim()
            p[Keys.dEndpoint] = config.downloadEndpoint.trim()
        }
    }
}
