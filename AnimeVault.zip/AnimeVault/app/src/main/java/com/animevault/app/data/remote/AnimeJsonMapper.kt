package com.animevault.app.data.remote

import com.animevault.app.domain.model.Anime
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/** Mapper tolerante: intenta entender distintos formatos JSON de APIs de anime. */
object AnimeJsonMapper {
    private val LIST_KEYS = listOf("data", "results", "result", "items", "animes", "anime", "media", "docs", "list", "Page")
    private val WRAP_KEYS = listOf("data", "result", "anime", "media", "Media", "item", "attributes")
    private val ID_KEYS = listOf("mal_id", "id", "_id", "slug", "anime_id", "animeId")
    private val TITLE_KEYS = listOf("title", "title_english", "name", "canonicalTitle", "title_romaji", "titleEnglish")
    private val IMAGE_KEYS = listOf(
        "large_image_url", "extraLarge", "large", "image_url", "cover", "poster", "image", "thumbnail",
        "picture", "coverImage", "cover_image", "posterImage", "poster_path", "img", "imageUrl", "posterUrl", "original", "medium"
    )
    private val SCORE_KEYS = listOf("score", "averageScore", "average_score", "rating", "mean", "vote_average", "averageRating")
    private val SYNOPSIS_KEYS = listOf("synopsis", "description", "overview", "summary", "plot")
    private val GENRE_KEYS = listOf("genres", "genre", "tags", "categories")
    private val EPISODE_KEYS = listOf("episodes", "episode_count", "episodeCount", "totalEpisodes", "num_episodes", "episodesCount")

    fun parseList(json: String): List<Anime> {
        val root = JsonParser.parseString(json)
        val arr = findArray(root, 0) ?: return emptyList()
        return arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            toAnime(unwrap(o), idOf(o))
        }
    }

    fun parseDetail(json: String, fallbackId: String): Anime? {
        val root = JsonParser.parseString(json) as? JsonObject ?: return null
        return toAnime(unwrap(root), idOf(root) ?: fallbackId)
    }

    private fun toAnime(o: JsonObject, id: String?): Anime? {
        val title = text(find(o, TITLE_KEYS)) ?: return null
        val finalId = id ?: idOf(o) ?: return null
        val score = find(o, SCORE_KEYS)?.let { runCatching { it.asDouble }.getOrNull() }
            ?.let { if (it > 10) it / 10 else it }?.takeIf { it > 0 }
        val synopsis = text(find(o, SYNOPSIS_KEYS))?.replace(Regex("<[^>]*>"), "")?.trim()
        val genres = (find(o, GENRE_KEYS) as? JsonArray)?.mapNotNull { genreName(it) }.orEmpty()
        val episodes = find(o, EPISODE_KEYS)?.let {
            if (it.isJsonArray) it.asJsonArray.size() else runCatching { it.asInt }.getOrNull()
        }
        return Anime(finalId, title, image(o), score, synopsis, genres, episodes)
    }

    private fun idOf(o: JsonObject): String? = text(find(o, ID_KEYS, 1))

    private fun hasTitle(o: JsonObject) = TITLE_KEYS.any { o.has(it) }

    private fun unwrap(o: JsonObject): JsonObject {
        var cur = o
        repeat(3) {
            if (hasTitle(cur)) return cur
            val next = WRAP_KEYS.firstNotNullOfOrNull { cur.get(it) as? JsonObject } ?: return cur
            cur = next
        }
        return cur
    }

    private fun findArray(e: JsonElement, depth: Int): JsonArray? {
        if (e.isJsonArray) return e.asJsonArray
        if (!e.isJsonObject || depth > 4) return null
        val o = e.asJsonObject
        for (k in LIST_KEYS) {
            val v = o.get(k) ?: continue
            findArray(v, depth + 1)?.let { return it }
        }
        for ((_, v) in o.entrySet()) findArray(v, depth + 1)?.let { return it }
        return null
    }

    private fun find(o: JsonObject, keys: List<String>, depth: Int = 3): JsonElement? {
        for (k in keys) {
            val v = o.get(k)
            if (v != null && !v.isJsonNull) return v
        }
        if (depth == 0) return null
        for ((_, v) in o.entrySet()) {
            if (v.isJsonObject) find(v.asJsonObject, keys, depth - 1)?.let { return it }
        }
        return null
    }

    private fun image(o: JsonObject): String? {
        var cur: JsonElement? = find(o, IMAGE_KEYS)
        var guard = 0
        while (cur != null && cur.isJsonObject && guard++ < 4) cur = find(cur.asJsonObject, IMAGE_KEYS)
        return (cur?.takeIf { it.isJsonPrimitive })?.asString?.takeIf { it.isNotBlank() }
    }

    private fun text(e: JsonElement?): String? {
        if (e == null || e.isJsonNull) return null
        if (e.isJsonPrimitive) return e.asString.takeIf { it.isNotBlank() }
        if (e.isJsonObject) {
            val o = e.asJsonObject
            return listOf("english", "romaji", "default", "en", "userPreferred", "native").firstNotNullOfOrNull { text(o.get(it)) }
        }
        return null
    }

    private fun genreName(e: JsonElement): String? {
        if (e.isJsonPrimitive) return e.asString.takeIf { it.isNotBlank() }
        if (e.isJsonObject) return text(find(e.asJsonObject, listOf("name", "title", "genre", "label"), 0))
        return null
    }
}
