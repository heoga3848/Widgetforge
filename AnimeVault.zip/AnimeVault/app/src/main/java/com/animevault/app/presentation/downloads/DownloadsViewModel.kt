package com.animevault.app.presentation.downloads

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.animevault.app.domain.model.DownloadItem
import com.animevault.app.domain.usecase.DownloadUseCases
import com.animevault.app.domain.usecase.ObserveSettingsUseCase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DownloadsViewModel(
    private val uc: DownloadUseCases,
    observeSettings: ObserveSettingsUseCase
) : ViewModel() {

    val items: StateFlow<List<DownloadItem>> = uc.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val configured: StateFlow<Boolean> = observeSettings.download.map { it.isConfigured }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun pause(id: Long) { viewModelScope.launch { uc.pause(id) } }
    fun resume(id: Long) { viewModelScope.launch { uc.resume(id) } }
    fun remove(id: Long) { viewModelScope.launch { uc.remove(id) } }
}
