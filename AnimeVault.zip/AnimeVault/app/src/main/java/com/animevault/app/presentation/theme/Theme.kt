package com.animevault.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFF7A3D),
    onPrimary = Color(0xFF1A0A02),
    secondary = Color(0xFF8B7CFF),
    background = Color(0xFF0B0B12),
    onBackground = Color(0xFFF2F2F7),
    surface = Color(0xFF14141F),
    onSurface = Color(0xFFF2F2F7),
    surfaceVariant = Color(0xFF1E1E2D),
    onSurfaceVariant = Color(0xFFA6A6BA),
    outline = Color(0xFF3A3A50),
    error = Color(0xFFFF6B6B)
)

@Composable
fun AnimeVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, typography = Typography(), content = content)
}
