package com.example.widgetforge

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Layer(
    var type: String = "text", var text: String = "Texto",
    var x: Float = 20f, var y: Float = 20f, var w: Float = 200f, var h: Float = 60f,
    var color: Int = -1, var size: Float = 32f, var radius: Float = 24f,
    var bold: Boolean = false, var progress: String = "battery",
    var rot: Float = 0f, var shadow: Float = 0f, var shColor: Int = 0x66000000,
    var stroke: Float = 0f, var strokeColor: Int = 0x99FFFFFF.toInt(), var color2: Int = 0xFF888888.toInt(),
    var grad: Boolean = false, var align: Int = 0, var font: String = "", var src: String = "",
    var sx: Float = 1f, var sy: Float = 1f, var skew: Float = 0f, var textCase: Int = 0
) {
    fun toJson() = JSONObject().put("type", type).put("text", text).put("x", x.toDouble()).put("y", y.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble()).put("color", color).put("size", size.toDouble())
        .put("radius", radius.toDouble()).put("bold", bold).put("progress", progress)
        .put("rot", rot.toDouble()).put("shadow", shadow.toDouble()).put("shColor", shColor)
        .put("stroke", stroke.toDouble()).put("strokeColor", strokeColor).put("color2", color2)
        .put("grad", grad).put("align", align).put("font", font).put("src", src)
        .put("sx", sx.toDouble()).put("sy", sy.toDouble()).put("skew", skew.toDouble()).put("textCase", textCase)

    companion object {
        fun from(o: JSONObject) = Layer(
            type = o.optString("type", "text"), text = o.optString("text", ""),
            x = o.optDouble("x", 0.0).toFloat(), y = o.optDouble("y", 0.0).toFloat(),
            w = o.optDouble("w", 100.0).toFloat(), h = o.optDouble("h", 100.0).toFloat(),
            color = o.optInt("color", -1), size = o.optDouble("size", 32.0).toFloat(), radius = o.optDouble("radius", 0.0).toFloat(),
            bold = o.optBoolean("bold", false), progress = o.optString("progress", "battery"),
            rot = o.optDouble("rot", 0.0).toFloat(), shadow = o.optDouble("shadow", 0.0).toFloat(), shColor = o.optInt("shColor", 0x66000000),
            stroke = o.optDouble("stroke", 0.0).toFloat(), strokeColor = o.optInt("strokeColor", 0x99FFFFFF.toInt()),
            color2 = o.optInt("color2", 0xFF888888.toInt()),
            grad = o.optBoolean("grad", false), align = o.optInt("align", 0), font = o.optString("font", ""), src = o.optString("src", ""),
            sx = o.optDouble("sx", 1.0).toFloat(), sy = o.optDouble("sy", 1.0).toFloat(),
            skew = o.optDouble("skew", 0.0).toFloat(), textCase = o.optInt("textCase", 0)
        )
    }
}

class Design(
    var id: String = UUID.randomUUID().toString(), var name: String = "Nuevo widget",
    var w: Float = 400f, var h: Float = 200f, var bg: Int = 0xCC101018.toInt(), var radius: Float = 36f,
    var sx: Float = 1f, var sy: Float = 1f, var fit: Int = 0   // fit: 0 = ajustar proporcional, 1 = deformar para llenar el widget
) {
    val layers = mutableListOf<Layer>()
    val globals = LinkedHashMap<String, String>()   // variables globales de KWGT: gv(nombre)

    /** Tamaño real del widget tras la deformación global. */
    val outW get() = w * sx
    val outH get() = h * sy

    /** Cambia el tamaño del lienzo; con [content] también reescala capas (posición, tamaño, textos...). */
    fun resize(nw: Float, nh: Float, content: Boolean) {
        if (content && w > 0f && h > 0f) {
            val fx = nw / w; val fy = nh / h; val k = minOf(fx, fy)
            for (l in layers) {
                l.x *= fx; l.y *= fy; l.w *= fx; l.h *= fy
                l.size *= if (l.type == "text" || l.type == "arc" || l.type == "calendar") k else 1f
                l.radius *= k; l.stroke *= k; l.shadow *= k
            }
            radius *= k
        }
        w = nw; h = nh
    }

    fun toJson() = JSONObject().put("id", id).put("name", name).put("w", w.toDouble()).put("h", h.toDouble())
        .put("bg", bg).put("radius", radius.toDouble())
        .put("sx", sx.toDouble()).put("sy", sy.toDouble()).put("fit", fit)
        .put("globals", JSONObject().also { g -> globals.forEach { (k, v) -> g.put(k, v) } })
        .put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })

    companion object {
        fun from(o: JSONObject): Design {
            val d = Design(
                o.optString("id", UUID.randomUUID().toString()), o.optString("name", "Widget"),
                o.optDouble("w", 400.0).toFloat(), o.optDouble("h", 200.0).toFloat(),
                o.optInt("bg", 0xCC101018.toInt()), o.optDouble("radius", 36.0).toFloat(),
                o.optDouble("sx", 1.0).toFloat(), o.optDouble("sy", 1.0).toFloat(), o.optInt("fit", 0)
            )
            val g = o.optJSONObject("globals")
            if (g != null) { val ks = g.keys(); while (ks.hasNext()) { val k = ks.next(); d.globals[k] = g.optString(k, "") } }
            val a = o.optJSONArray("layers") ?: JSONArray()
            for (i in 0 until a.length()) d.layers.add(Layer.from(a.getJSONObject(i)))
            return d
        }
    }
}

object Vars {
    private val vx = Regex("\\{(\\w+)(?::([^}]*))?\\}")
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.getDefault()).format(Date())

    private fun sticky(c: Context): Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    fun battery(c: Context): Int = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    fun charging(c: Context): Boolean {
        val st = sticky(c)?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    fun batteryTemp(c: Context): Double = (sticky(c)?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0

    fun num(c: Context, k: String): Float = when (k) {
        "battery" -> battery(c) / 100f
        "minute" -> Calendar.getInstance().get(Calendar.MINUTE) / 60f
        "hour" -> Calendar.getInstance().get(Calendar.HOUR_OF_DAY) / 24f
        "storage" -> StatFs(Environment.getDataDirectory().path).let { it.availableBytes.toFloat() / it.totalBytes }
        else -> 0f
    }

    /** Progreso 0..1: una clave conocida (battery, minute, hour, storage) o una fórmula/número en porcentaje (0..100). */
    fun progress(c: Context, k: String, g: Map<String, String> = emptyMap()): Float {
        if (k == "battery" || k == "minute" || k == "hour" || k == "storage") return num(c, k)
        val v = resolve(c, k, g).trim().toFloatOrNull() ?: return 0f
        return (v / 100f).coerceIn(0f, 1f)
    }

    private fun days(s: String): String = runCatching {
        val t = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)!!.time
        Math.ceil((t - System.currentTimeMillis()) / 86400000.0).toInt().toString()
    }.getOrDefault("?")

    // Fórmulas Kustom entre $...$ (ver Formula.kt) y variables {time} {hh} {mm} {ss} {date} {day} {month} {battery} {storage} {days:2026-12-25}
    fun resolve(c: Context, s: String, g: Map<String, String> = emptyMap()): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '$') {
                var j = i + 1
                var q = false
                while (j < s.length && (q || s[j] != '$')) { if (s[j] == '"') q = !q; j++ }
                if (j < s.length) { sb.append(Formula.eval(c, s.substring(i + 1, j), g)); i = j + 1; continue }
            }
            sb.append(ch); i++
        }
        return vx.replace(sb.toString()) { m ->
            when (m.groupValues[1]) {
                "time" -> fmt("HH:mm"); "hh" -> fmt("HH"); "mm" -> fmt("mm"); "ss" -> fmt("ss")
                "date" -> fmt("dd/MM/yyyy"); "day" -> fmt("EEEE"); "month" -> fmt("MMMM")
                "battery" -> battery(c).toString()
                "storage" -> (num(c, "storage") * 100).toInt().toString()
                "days" -> days(m.groupValues[2])
                else -> m.value
            }
        }
    }
}

object Store {
    private fun dir(c: Context) = File(c.filesDir, "designs").apply { mkdirs() }
    private fun prefs(c: Context) = c.getSharedPreferences("map", 0)

    fun list(c: Context): List<Design> = dir(c).listFiles()
        ?.mapNotNull { f -> runCatching { Design.from(JSONObject(f.readText())) }.getOrNull() }
        ?.sortedBy { it.name } ?: emptyList()

    fun save(c: Context, d: Design) {
        File(dir(c), "${d.id}.json").writeText(d.toJson().toString()); WidgetForgeProvider.refreshAll(c)
    }

    fun delete(c: Context, d: Design) { File(dir(c), "${d.id}.json").delete() }
    fun assign(c: Context, wid: Int, id: String) = prefs(c).edit().putString(wid.toString(), id).apply()
    fun unassign(c: Context, wid: Int) = prefs(c).edit().remove(wid.toString()).apply()
    fun designFor(c: Context, wid: Int): Design? =
        prefs(c).getString(wid.toString(), null)?.let { id -> list(c).firstOrNull { it.id == id } }

    fun templates() = listOf(
        Design(name = "Reloj cristal", bg = 0, radius = 0f).also { d ->
            d.layers += Layer(type = "text", text = "{hh}:{mm}", x = 20f, y = 20f, w = 360f, size = 120f, align = 1, bold = true,
                color = 0xE6FFFFFF.toInt(), color2 = 0x66C8C8C8, grad = true, stroke = 1.5f, strokeColor = 0x99FFFFFF.toInt(), shadow = 6f, shColor = 0x55000000)
            d.layers += Layer(type = "text", text = "{day}, {date}", x = 20f, y = 150f, w = 360f, size = 24f, align = 1, color = 0xCCFFFFFF.toInt())
        },
        Design(name = "Calendario", w = 300f, h = 260f, bg = 0xAAD6F3EE.toInt(), radius = 28f).also { d ->
            d.layers += Layer(type = "text", text = "{month}", x = 20f, y = 12f, size = 22f, bold = true, color = 0xFF2B6F66.toInt())
            d.layers += Layer(type = "calendar", x = 14f, y = 48f, w = 272f, h = 196f, size = 14f, color = 0xFF2B6F66.toInt(), color2 = 0xFF3DBFAE.toInt())
        },
        Design(name = "Reloj", w = 400f, h = 200f).also { d ->
            d.layers += Layer("text", "{hh}:{mm}", 24f, 16f, 0f, 0f, -1, 96f, 0f, true)
            d.layers += Layer("text", "{day}  {date}", 28f, 128f, 0f, 0f, 0xFF00F2FF.toInt(), 26f)
        },
        Design(name = "Anillo de batería", w = 300f, h = 300f, radius = 150f).also { d ->
            d.layers += Layer("arc", "", 30f, 30f, 240f, 240f, 0xFF00FF88.toInt(), 24f, 0f, false, "battery")
            d.layers += Layer(type = "text", text = "{battery}", x = 30f, y = 105f, w = 240f, size = 80f, bold = true, align = 1)
        }
    )
}
