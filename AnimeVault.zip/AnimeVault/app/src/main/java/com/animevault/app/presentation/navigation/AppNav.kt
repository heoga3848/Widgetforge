package com.animevault.app.presentation.navigation

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.animevault.app.AppContainer
import com.animevault.app.presentation.detail.DetailScreen
import com.animevault.app.presentation.detail.DetailViewModel
import com.animevault.app.presentation.downloads.DownloadsScreen
import com.animevault.app.presentation.downloads.DownloadsViewModel
import com.animevault.app.presentation.mylist.MyListScreen
import com.animevault.app.presentation.mylist.MyListViewModel
import com.animevault.app.presentation.search.SearchScreen
import com.animevault.app.presentation.search.SearchViewModel
import com.animevault.app.presentation.settings.SettingsScreen
import com.animevault.app.presentation.settings.SettingsViewModel

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    SEARCH("search", "Buscar", Icons.Rounded.Search),
    LIST("list", "Mi Lista", Icons.Rounded.Bookmarks),
    DOWNLOADS("downloads", "Descargas", Icons.Rounded.Download),
    SETTINGS("settings", "Ajustes", Icons.Rounded.Settings)
}

@Composable
inline fun <reified VM : ViewModel> appViewModel(key: String? = null, crossinline create: () -> VM): VM =
    viewModel<VM>(key = key, factory = viewModelFactory { initializer { create() } })

@Composable
fun AppRoot(c: AppContainer) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val tabRoutes = Tab.entries.map { it.route }

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (route in tabRoutes) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { goTab(t.route) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = Tab.SEARCH.route, modifier = Modifier.padding(padding)) {
            composable(Tab.SEARCH.route) {
                val vm = appViewModel<SearchViewModel> { SearchViewModel(c.searchAnime, c.observeSettings) }
                SearchScreen(
                    vm,
                    onOpenDetail = { nav.navigate("detail/${Uri.encode(it)}") },
                    onOpenSettings = { goTab(Tab.SETTINGS.route) }
                )
            }
            composable(Tab.LIST.route) {
                val vm = appViewModel<MyListViewModel> { MyListViewModel(c.myList) }
                MyListScreen(vm, onOpenDetail = { nav.navigate("detail/${Uri.encode(it)}") })
            }
            composable(Tab.DOWNLOADS.route) {
                val vm = appViewModel<DownloadsViewModel> { DownloadsViewModel(c.downloads, c.observeSettings) }
                DownloadsScreen(vm, onOpenSettings = { goTab(Tab.SETTINGS.route) })
            }
            composable(Tab.SETTINGS.route) {
                val vm = appViewModel<SettingsViewModel> {
                    SettingsViewModel(c.observeSettings, c.saveSettings, c.testContent, c.testDownload)
                }
                SettingsScreen(vm)
            }
            composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                val vm = appViewModel<DetailViewModel>(key = "detail_$id") {
                    DetailViewModel(id, c.getDetail, c.myList, c.downloads)
                }
                DetailScreen(vm, onBack = { nav.popBackStack() }, onOpenSettings = { goTab(Tab.SETTINGS.route) })
            }
        }
    }
}
