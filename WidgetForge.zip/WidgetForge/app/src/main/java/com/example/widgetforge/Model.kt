package com.example.widgetforge

import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Layer(
    var type: String = "text", var text: String = "Texto",
    var x: Float = 20f, var y: Float = 20f, var w: Float = 200f, var h: Float = 60f,
    var color: Int = -1, var size: Float = 32f, var radius: Float = 24f,
    var bold: Boolean = false, var progress: String = "battery"
) {
    fun toJson() = JSONObject().put("type", type).put("text", text).put("x", x.toDouble()).put("y", y.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble()).put("color", color).put("size", size.toDouble())
        .put("radius", radius.toDouble()).put("bold", bold).put("progress", progress)

    companion object {
        fun from(o: JSONObject) = Layer(
            o.optString("type", "text"), o.optString("text", ""),
            o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat(),
            o.optDouble("w", 100.0).toFloat(), o.optDouble("h", 100.0).toFloat(),
            o.optInt("color", -1), o.optDouble("size", 32.0).toFloat(), o.optDouble("radius", 0.0).toFloat(),
            o.optBoolean("bold", false), o.optString("progress", "battery")
        )
    }
}

class Design(
    var id: String = UUID.randomUUID().toString(), var name: String = "Nuevo widget",
    var w: Float = 400f, var h: Float = 200f, var bg: Int = 0xCC101018.toInt(), var radius: Float = 36f
) {
    val layers = mutableListOf<Layer>()

    fun toJson() = JSONObject().put("id", id).put("name", name).put("w", w.toDouble()).put("h", h.toDouble())
        .put("bg", bg).put("radius", radius.toDouble()).put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })

    companion object {
        fun from(o: JSONObject): Design {
            val d = Design(
                o.optString("id", UUID.randomUUID().toString()), o.optString("name", "Widget"),
                o.optDouble("w", 400.0).toFloat(), o.optDouble("h", 200.0).toFloat(),
                o.optInt("bg", 0xCC101018.toInt()), o.optDouble("radius", 36.0).toFloat()
            )
            val a = o.optJSONArray("layers") ?: JSONArray()
            for (i in 0 until a.length()) d.layers.add(Layer.from(a.getJSONObject(i)))
            return d
        }
    }
}

object Vars {
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.getDefault()).format(Date())
    fun battery(c: Context) = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    fun num(c: Context, k: String): Float = when (k) {
        "battery" -> battery(c) / 100f
        "minute" -> Calendar.getInstance().get(Calendar.MINUTE) / 60f
        "hour" -> Calendar.getInstance().get(Calendar.HOUR_OF_DAY) / 24f
        "storage" -> StatFs(Environment.getDataDirectory().path).let { it.availableBytes.toFloat() / it.totalBytes }
        else -> 0f
    }

    // Variables: {time} {hh} {mm} {ss} {date} {day} {month} {battery} {storage}
    fun resolve(c: Context, s: String): String = Regex("\\{(\\w+)\\}").replace(s) { m ->
        when (m.groupValues[1]) {
            "time" -> fmt("HH:mm"); "hh" -> fmt("HH"); "mm" -> fmt("mm"); "ss" -> fmt("ss")
            "date" -> fmt("dd/MM/yyyy"); "day" -> fmt("EEEE"); "month" -> fmt("MMMM")
            "battery" -> battery(c).toString()
            "storage" -> (num(c, "storage") * 100).toInt().toString()
            else -> m.value
        }
    }
}

object Store {
    private fun dir(c: Context) = File(c.filesDir, "designs").apply { mkdirs() }
    private fun prefs(c: Context) = c.getSharedPreferences("map", 0)

    fun list(c: Context): List<Design> = dir(c).listFiles()
        ?.mapNotNull { f -> runCatching { Design.from(JSONObject(f.readText())) }.getOrNull() }
        ?.sortedBy { it.name } ?: emptyList()

    fun save(c: Context, d: Design) {
        File(dir(c), "${d.id}.json").writeText(d.toJson().toString()); WidgetForgeProvider.refreshAll(c)
    }

    fun delete(c: Context, d: Design) { File(dir(c), "${d.id}.json").delete() }
    fun assign(c: Context, wid: Int, id: String) = prefs(c).edit().putString(wid.toString(), id).apply()
    fun unassign(c: Context, wid: Int) = prefs(c).edit().remove(wid.toString()).apply()
    fun designFor(c: Context, wid: Int): Design? =
        prefs(c).getString(wid.toString(), null)?.let { id -> list(c).firstOrNull { it.id == id } }

    fun templates() = listOf(
        Design(name = "Reloj").also { d ->
            d.layers += Layer("text", "{hh}:{mm}", 24f, 16f, 0f, 0f, -1, 96f, 0f, true)
            d.layers += Layer("text", "{day}  {date}", 28f, 128f, 0f, 0f, 0xFF00F2FF.toInt(), 26f)
        },
        Design(name = "Anillo de batería", w = 300f, h = 300f, radius = 150f).also { d ->
            d.layers += Layer("arc", "", 30f, 30f, 240f, 240f, 0xFF00FF88.toInt(), 24f, 0f, false, "battery")
            d.layers += Layer("text", "{battery}%", 85f, 115f, 0f, 0f, -1, 64f, 0f, true)
        }
    )
}
