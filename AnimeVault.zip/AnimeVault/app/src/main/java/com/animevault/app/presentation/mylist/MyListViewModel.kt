package com.animevault.app.presentation.mylist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.animevault.app.domain.model.Anime
import com.animevault.app.domain.model.ListEntry
import com.animevault.app.domain.model.ListStatus
import com.animevault.app.domain.usecase.MyListUseCases
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ListTab(val label: String) {
    VIEWING("Viendo"), COMPLETED("Completado"), PENDING("Pendiente"), FAVORITES("Favoritos")
}

class MyListViewModel(private val uc: MyListUseCases) : ViewModel() {
    private val tab = MutableStateFlow(ListTab.VIEWING)
    val selected: StateFlow<ListTab> = tab.asStateFlow()

    val items: StateFlow<List<ListEntry>> = combine(uc.observeAll(), tab) { all, t ->
        when (t) {
            ListTab.VIEWING -> all.filter { it.status == ListStatus.VIEWING }
            ListTab.COMPLETED -> all.filter { it.status == ListStatus.COMPLETED }
            ListTab.PENDING -> all.filter { it.status == ListStatus.PENDING }
            ListTab.FAVORITES -> all.filter { it.favorite }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun select(t: ListTab) { tab.value = t }

    fun setStatus(e: ListEntry, s: ListStatus) { viewModelScope.launch { uc.setStatus(e.toAnime(), s) } }
    fun toggleFavorite(e: ListEntry) { viewModelScope.launch { uc.toggleFavorite(e.toAnime()) } }
    fun remove(e: ListEntry) { viewModelScope.launch { uc.remove(e.animeId) } }

    private fun ListEntry.toAnime() = Anime(animeId, title, coverUrl, score)
}
