package com.animevault.app

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.animevault.app.data.local.SettingsRepositoryImpl
import com.animevault.app.data.local.db.AppDatabase
import com.animevault.app.data.repository.ContentRepositoryImpl
import com.animevault.app.data.repository.DownloadRepositoryImpl
import com.animevault.app.data.repository.MyListRepositoryImpl
import com.animevault.app.domain.repository.*
import com.animevault.app.domain.usecase.*

class AppContainer(context: Context) {
    val settings: SettingsRepository = SettingsRepositoryImpl(context)
    val database: AppDatabase = Room.databaseBuilder(context, AppDatabase::class.java, "animevault.db").build()

    private val contentRepo: ContentRepository = ContentRepositoryImpl(settings)
    private val myListRepo: MyListRepository = MyListRepositoryImpl(database.myListDao())
    private val downloadRepo: DownloadRepository = DownloadRepositoryImpl(context, database.downloadDao(), settings)

    val searchAnime = SearchAnimeUseCase(contentRepo)
    val getDetail = GetAnimeDetailUseCase(contentRepo)
    val testContent = TestContentConnectionUseCase(contentRepo)
    val testDownload = TestDownloadConnectionUseCase(downloadRepo)
    val observeSettings = ObserveSettingsUseCase(settings)
    val saveSettings = SaveSettingsUseCase(settings)
    val myList = MyListUseCases(myListRepo)
    val downloads = DownloadUseCases(downloadRepo)
}

class AnimeVaultApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
