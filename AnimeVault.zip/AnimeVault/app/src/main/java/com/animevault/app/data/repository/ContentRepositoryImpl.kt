package com.animevault.app.data.repository

import android.net.Uri
import com.animevault.app.data.remote.AnimeJsonMapper
import com.animevault.app.data.remote.Http
import com.animevault.app.domain.model.*
import com.animevault.app.domain.repository.ContentRepository
import com.animevault.app.domain.repository.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class ContentRepositoryImpl(private val settings: SettingsRepository) : ContentRepository {

    override suspend fun search(query: String): AppResult<List<Anime>> {
        val cfg = settings.contentConfig.first()
        if (!cfg.isConfigured) return AppResult.NotConfigured
        return when (val r = request(cfg, searchEndpoint(cfg, query))) {
            is AppResult.Success -> try {
                AppResult.Success(AnimeJsonMapper.parseList(r.data))
            } catch (e: Exception) {
                AppResult.Error("La respuesta no es un JSON válido:\n${r.data.take(300)}")
            }
            is AppResult.Error -> r
            AppResult.NotConfigured -> r
        }
    }

    override suspend fun detail(id: String): AppResult<Anime> {
        val cfg = settings.contentConfig.first()
        if (!cfg.isConfigured) return AppResult.NotConfigured
        val ep = cfg.detailEndpoint.replace("{id}", Uri.encode(id))
        return when (val r = request(cfg, ep)) {
            is AppResult.Success -> {
                val anime = runCatching { AnimeJsonMapper.parseDetail(r.data, id) }.getOrNull()
                if (anime != null) AppResult.Success(anime)
                else AppResult.Error("La API respondió, pero no pude encontrar el título/datos del anime:\n${r.data.take(300)}")
            }
            is AppResult.Error -> r
            AppResult.NotConfigured -> r
        }
    }

    override suspend fun testConnection(config: ContentConfig): AppResult<String> {
        if (config.baseUrl.isBlank() || config.searchEndpoint.isBlank())
            return AppResult.Error("Completa la Base URL y el endpoint de búsqueda")
        return when (val r = request(config, searchEndpoint(config, "naruto"))) {
            is AppResult.Success -> {
                val n = runCatching { AnimeJsonMapper.parseList(r.data).size }.getOrNull()
                if (n == null) AppResult.Error("Responde, pero no devuelve JSON válido:\n${r.data.take(200)}")
                else AppResult.Success("✅ Conexión correcta. Resultados reconocidos: $n")
            }
            is AppResult.Error -> r
            AppResult.NotConfigured -> r
        }
    }

    private fun searchEndpoint(cfg: ContentConfig, query: String): String {
        val q = Uri.encode(query.trim())
        return if (cfg.searchEndpoint.contains("{q}")) cfg.searchEndpoint.replace("{q}", q)
        else cfg.searchEndpoint + q
    }

    private suspend fun request(cfg: ContentConfig, endpoint: String): AppResult<String> =
        withContext(Dispatchers.IO) {
            try {
                val resp = Http.api(cfg.baseUrl).get(Http.relative(endpoint), Http.authHeaders(cfg.apiKey))
                if (resp.isSuccessful) {
                    AppResult.Success(resp.body()?.string().orEmpty())
                } else {
                    val body = resp.errorBody()?.string().orEmpty().take(300)
                    AppResult.Error("HTTP ${resp.code()} ${resp.message()}\n$body")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppResult.Error(Http.describeError(e))
            }
        }
}
