package com.animevault.app.domain.model

data class Anime(
    val id: String,
    val title: String,
    val coverUrl: String?,
    val score: Double?,
    val synopsis: String? = null,
    val genres: List<String> = emptyList(),
    val episodes: Int? = null
)

enum class ListStatus(val label: String) {
    VIEWING("Viendo"), COMPLETED("Completado"), PENDING("Pendiente")
}

data class ListEntry(
    val animeId: String,
    val title: String,
    val coverUrl: String?,
    val score: Double?,
    val status: ListStatus?,
    val favorite: Boolean
)

enum class DownloadState { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED }

data class DownloadItem(
    val id: Long,
    val animeId: String,
    val title: String,
    val state: DownloadState,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBps: Long,
    val filePath: String?,
    val error: String?
)

data class ContentConfig(
    val baseUrl: String = "",
    val apiKey: String = "",
    val searchEndpoint: String = "",
    val detailEndpoint: String = ""
) {
    val isConfigured: Boolean
        get() = baseUrl.isNotBlank() && searchEndpoint.isNotBlank() && detailEndpoint.isNotBlank()
}

data class DownloadConfig(
    val baseUrl: String = "",
    val apiKey: String = "",
    val downloadEndpoint: String = ""
) {
    val isConfigured: Boolean
        get() = baseUrl.isNotBlank() && downloadEndpoint.isNotBlank()
}

sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(val message: String) : AppResult<Nothing>
    data object NotConfigured : AppResult<Nothing>
}
