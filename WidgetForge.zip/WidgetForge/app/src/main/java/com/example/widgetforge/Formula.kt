package com.example.widgetforge

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Evaluador de fórmulas Kustom ($...$) para las funciones que no dependen de sensores externos.
 * Soportadas: df tf bi mu tc if gv, operadores aritméticos, comparaciones, & | ! y texto entre comillas.
 * Cualquier otra función (wi, mi, ai, nc, ci...) devuelve texto vacío.
 */
object Formula {
    val SUPPORTED = setOf("df", "tf", "bi", "mu", "tc", "if", "gv")
    private val fnRx = Regex("\\b([A-Za-z]{2})\\(")

    /** Nombres de funciones de un texto con fórmulas que este evaluador no entiende. */
    fun unsupportedIn(text: String): Set<String> {
        if (!text.contains('$')) return emptySet()
        val out = LinkedHashSet<String>()
        for (m in fnRx.findAll(text)) {
            val n = m.groupValues[1].lowercase()
            if (n !in SUPPORTED) out.add(n)
        }
        return out
    }

    fun eval(c: Context, expr: String, g: Map<String, String>): String =
        runCatching { Parser(c, expr.trim(), g).parse().s }.getOrDefault(expr.trim())

    private class Fallback : Exception()

    private class V(val s: String, val bare: Boolean = false) {
        fun num(): Double? = s.trim().toDoubleOrNull()
    }

    private fun fmt(d: Double): String =
        if (d.isNaN() || d.isInfinite()) "0"
        else if (d == Math.rint(d) && Math.abs(d) < 1e15) d.toLong().toString()
        else String.format(Locale.US, "%.2f", d).trimEnd('0').trimEnd('.')

    private class Parser(val c: Context, val src: String, val g: Map<String, String>) {
        var p = 0

        fun parse(): V {
            val v = orE()
            ws()
            if (p != src.length) throw Fallback()
            return v
        }

        private fun ws() { while (p < src.length && src[p].isWhitespace()) p++ }
        private fun at(s: String): Boolean { ws(); return src.startsWith(s, p) }
        private fun b(x: Boolean) = V(if (x) "1" else "0")
        private fun truth(v: V): Boolean {
            val n = v.num()
            return if (n != null) n != 0.0 else v.s.isNotEmpty() && !v.s.equals("false", true)
        }
        private fun numOf(v: V): Double {
            if (v.bare) throw Fallback()
            return v.num() ?: throw Fallback()
        }

        private fun orE(): V {
            var a = andE()
            while (at("|")) {
                p++; if (p < src.length && src[p] == '|') p++
                val r = andE(); a = b(truth(a) || truth(r))
            }
            return a
        }

        private fun andE(): V {
            var a = cmpE()
            while (at("&")) {
                p++; if (p < src.length && src[p] == '&') p++
                val r = cmpE(); a = b(truth(a) && truth(r))
            }
            return a
        }

        private fun cmpE(): V {
            var a = addE()
            while (true) {
                ws()
                var len = 2
                val op: String = when {
                    src.startsWith("<=", p) -> "<="
                    src.startsWith(">=", p) -> ">="
                    src.startsWith("!=", p) -> "!="
                    src.startsWith("<>", p) -> "!="
                    src.startsWith("==", p) -> "="
                    src.startsWith("<", p) -> { len = 1; "<" }
                    src.startsWith(">", p) -> { len = 1; ">" }
                    src.startsWith("=", p) -> { len = 1; "=" }
                    else -> return a
                }
                p += len
                val r = addE()
                a = compare(a, op, r)
            }
        }

        private fun compare(a: V, op: String, r: V): V {
            val x = a.num(); val y = r.num()
            if (x != null && y != null && !a.bare && !r.bare) {
                return b(when (op) {
                    "<" -> x < y
                    ">" -> x > y
                    "<=" -> x <= y
                    ">=" -> x >= y
                    "!=" -> x != y
                    else -> x == y
                })
            }
            val k = a.s.compareTo(r.s)
            return b(when (op) {
                "=" -> k == 0
                "!=" -> k != 0
                "<" -> k < 0
                ">" -> k > 0
                "<=" -> k <= 0
                else -> k >= 0
            })
        }

        private fun addE(): V {
            var a = mulE()
            while (true) {
                if (at("+")) {
                    p++
                    val r = mulE()
                    if (a.bare || r.bare) throw Fallback()
                    val x = a.num(); val y = r.num()
                    a = if (x != null && y != null) V(fmt(x + y)) else V(a.s + r.s)
                } else if (at("-")) {
                    p++
                    val r = mulE()
                    a = V(fmt(numOf(a) - numOf(r)))
                } else return a
            }
        }

        private fun mulE(): V {
            var a = unaryE()
            while (true) {
                val op = when {
                    at("*") -> '*'
                    at("/") -> '/'
                    at("%") -> '%'
                    else -> return a
                }
                p++
                val r = unaryE()
                val x = numOf(a); val y = numOf(r)
                a = V(fmt(when (op) {
                    '*' -> x * y
                    '/' -> if (y == 0.0) 0.0 else x / y
                    else -> if (y == 0.0) 0.0 else x % y
                }))
            }
        }

        private fun unaryE(): V {
            ws()
            if (p < src.length && src[p] == '-') { p++; return V(fmt(-numOf(unaryE()))) }
            if (p < src.length && src[p] == '!' && !src.startsWith("!=", p)) { p++; return b(!truth(unaryE())) }
            return primary()
        }

        private fun primary(): V {
            ws()
            if (p >= src.length) throw Fallback()
            val ch = src[p]
            if (ch == '(') {
                p++
                val v = orE()
                ws()
                if (p >= src.length || src[p] != ')') throw Fallback()
                p++
                return v
            }
            if (ch == '"' || ch == '\'') {
                val e = src.indexOf(ch, p + 1)
                if (e < 0) throw Fallback()
                val s = src.substring(p + 1, e)
                p = e + 1
                return V(s)
            }
            if (ch.isDigit() || ch == '.') {
                val st = p
                while (p < src.length && (src[p].isDigit() || src[p] == '.')) p++
                return V(src.substring(st, p))
            }
            if (ch.isLetter() || ch == '_') {
                val st = p
                while (p < src.length && (src[p].isLetterOrDigit() || src[p] == '_')) p++
                val name = src.substring(st, p)
                if (p < src.length && src[p] == '(') return call(name.lowercase(), rawArgs())
                return V(name, true)
            }
            throw Fallback()
        }

        /** Con p sobre '(' devuelve los argumentos en bruto (separados por comas del nivel 1) y deja p tras ')'. */
        private fun rawArgs(): List<String> {
            val out = ArrayList<String>()
            var depth = 0
            var q = '\u0000'
            var st = p + 1
            var i = p
            while (i < src.length) {
                val ch = src[i]
                if (q != '\u0000') {
                    if (ch == q) q = '\u0000'
                } else if (ch == '"' || ch == '\'') {
                    q = ch
                } else if (ch == '(') {
                    depth++
                } else if (ch == ')') {
                    depth--
                    if (depth == 0) { out.add(src.substring(st, i)); p = i + 1; return out }
                } else if (ch == ',' && depth == 1) {
                    out.add(src.substring(st, i)); st = i + 1
                }
                i++
            }
            throw Fallback()
        }

        private fun lit(raw: String): String {
            val t = raw.trim()
            return if (t.length >= 2 && (t[0] == '"' || t[0] == '\'') && t.last() == t[0]) t.substring(1, t.length - 1) else t
        }

        /** Evalúa un argumento; si no es una expresión válida lo trata como texto literal (df(HH:mm)). */
        private fun ev(raw: String): V {
            val t = raw.trim()
            if (t.isEmpty()) return V("")
            return try { Parser(c, t, g).parse() } catch (e: Exception) { V(lit(t), true) }
        }

        private fun nv(raw: String): Double = ev(raw).num() ?: 0.0

        private fun call(fn: String, a: List<String>): V {
            val first = if (a.isNotEmpty()) a[0] else ""
            return when (fn) {
                "df", "tf" -> {
                    val f = lit(first)
                    V(runCatching { SimpleDateFormat(f, Locale.getDefault()).format(Date()) }.getOrDefault(f))
                }
                "bi" -> when (lit(first).lowercase()) {
                    "level" -> V(Vars.battery(c).toString())
                    "charging" -> V(if (Vars.charging(c)) "1" else "0")
                    "temp" -> V(fmt(Vars.batteryTemp(c)))
                    else -> V("")
                }
                "mu" -> mu(lit(first).lowercase(), a.drop(1).map { nv(it) })
                "tc" -> tc(lit(first).lowercase(), a.drop(1))
                "if" -> iff(a)
                "gv" -> V(g[lit(first)] ?: "")
                else -> V("")
            }
        }

        private fun mu(op: String, n: List<Double>): V {
            val x = if (n.isNotEmpty()) n[0] else 0.0
            val y = if (n.size > 1) n[1] else 0.0
            val r: Double = when (op) {
                "abs" -> Math.abs(x)
                "ceil" -> Math.ceil(x)
                "floor" -> Math.floor(x)
                "round" -> Math.floor(x + 0.5)
                "sqrt" -> Math.sqrt(x)
                "sin" -> Math.sin(Math.toRadians(x))
                "cos" -> Math.cos(Math.toRadians(x))
                "min" -> Math.min(x, y)
                "max" -> Math.max(x, y)
                "pow" -> Math.pow(x, y)
                "log" -> Math.log(x)
                "rnd" -> Math.random() * x
                else -> 0.0
            }
            return V(fmt(r))
        }

        private fun tc(op: String, rest: List<String>): V {
            val s = if (rest.isNotEmpty()) ev(rest[0]).s else ""
            return when (op) {
                "up" -> V(s.uppercase())
                "low" -> V(s.lowercase())
                "cap" -> V(s.split(" ").joinToString(" ") { w -> w.replaceFirstChar { ch -> ch.uppercase() } })
                "len" -> V(s.length.toString())
                "rev" -> V(s.reversed())
                "utf" -> V(s.toIntOrNull(16)?.let { cp -> String(Character.toChars(cp)) } ?: "")
                "cut" -> {
                    if (rest.size > 2) {
                        val a1 = nv(rest[1]).toInt().coerceIn(0, s.length)
                        val a2 = nv(rest[2]).toInt().coerceIn(a1, s.length)
                        V(s.substring(a1, a2))
                    } else {
                        val n = if (rest.size > 1) nv(rest[1]).toInt() else s.length
                        V(s.take(n.coerceAtLeast(0)))
                    }
                }
                else -> V(s)
            }
        }

        private fun iff(a: List<String>): V {
            var i = 0
            while (i + 1 < a.size) {
                if (truth(ev(a[i]))) return ev(a[i + 1])
                i += 2
            }
            return if (i < a.size) ev(a[i]) else V("")
        }
    }
}
