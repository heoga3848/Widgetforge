package com.example.widgetforge

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Assets {
    fun dir(c: Context) = File(c.filesDir, "assets").apply { mkdirs() }
    private val bmps = HashMap<String, Bitmap?>()
    private val fonts = HashMap<String, Typeface?>()

    fun bitmap(c: Context, n: String): Bitmap? = bmps.getOrPut(n) {
        val f = File(dir(c), n)
        if (n.isEmpty() || !f.exists()) null else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / s > 1400 || o.outHeight / s > 1400) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }
    }

    fun typeface(c: Context, n: String): Typeface? = fonts.getOrPut(n) {
        runCatching { Typeface.createFromFile(File(dir(c), n)) }.getOrNull()
    }

    fun copyIn(c: Context, uri: Uri, ext: String): String {
        val n = "${UUID.randomUUID()}.$ext"
        c.contentResolver.openInputStream(uri)!!.use { i -> File(dir(c), n).outputStream().use { i.copyTo(it) } }
        return n
    }
}

/** Resultado de importar un archivo: el diseño (o null), notas para el usuario y el error si falló. */
class ImportResult(val design: Design?, val notes: List<String> = emptyList(), val error: String? = null)

object Importer {
    /**
     * Acepta: .kwgt / .klwp / .klck (zip con preset.json), un preset.json suelto,
     * zips que contengan varios presets o varios .kwgt dentro, y el formato propio (.zip/.wforge con design.json).
     */
    fun readAll(c: Context, uri: Uri): List<ImportResult> {
        val bytes = c.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        return parse(c, bytes, 0)
    }

    private fun isZip(b: ByteArray) = b.size > 3 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()

    private fun unzip(bytes: ByteArray): Map<String, ByteArray> {
        fun readWith(cs: java.nio.charset.Charset): Map<String, ByteArray> {
            val files = LinkedHashMap<String, ByteArray>()
            ZipInputStream(bytes.inputStream(), cs).use { z ->
                var e = z.nextEntry
                while (e != null) { if (!e.isDirectory) files[e.name] = z.readBytes(); e = z.nextEntry }
            }
            return files
        }
        return try { readWith(Charsets.UTF_8) } catch (ex: Exception) { readWith(Charsets.ISO_8859_1) }
    }

    private fun parse(c: Context, bytes: ByteArray, depth: Int): List<ImportResult> {
        if (!isZip(bytes)) return listOf(parseJson(c, String(bytes, Charsets.UTF_8), emptyMap()))
        val files = unzip(bytes)

        val own = files.keys.firstOrNull { it.endsWith("design.json") }
        if (own != null) {
            files.forEach { (k, v) -> if (k.startsWith("assets/")) File(Assets.dir(c), k.removePrefix("assets/")).writeBytes(v) }
            return listOf(parseJson(c, String(files.getValue(own), Charsets.UTF_8), files))
        }

        val out = ArrayList<ImportResult>()
        val presets = files.keys.filter { it.endsWith("preset.json") }
        for (k in presets) {
            val base = k.removeSuffix("preset.json")
            val scope = if (presets.size > 1) files.filterKeys { it.startsWith(base) } else files
            out.add(parseJson(c, String(files.getValue(k), Charsets.UTF_8), scope))
        }
        if (depth < 2) {
            for ((k, v) in files) {
                val n = k.lowercase()
                if (n.endsWith(".kwgt") || n.endsWith(".klwp") || n.endsWith(".klck") || n.endsWith(".zip")) out.addAll(parse(c, v, depth + 1))
            }
        }
        if (out.isEmpty()) out.add(ImportResult(null, error = "No encontré preset.json ni design.json dentro del archivo"))
        return out
    }

    private fun parseJson(c: Context, text: String, files: Map<String, ByteArray>): ImportResult {
        val o = try { JSONObject(text.trim().removePrefix("\uFEFF")) } catch (e: Exception) {
            return ImportResult(null, error = "El archivo no contiene un JSON válido")
        }
        return when {
            o.has("layers") -> Design.from(o).let { ImportResult(it, listOf("Diseño WidgetForge (${it.layers.size} capas)")) }
            o.has("preset_root") -> Kwgt.convert(c, o, files)
            else -> ImportResult(null, error = "Formato no reconocido (no es WidgetForge ni KWGT)")
        }
    }

    fun export(c: Context, d: Design, out: OutputStream) {
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("design.json")); z.write(d.toJson().toString().toByteArray()); z.closeEntry()
            d.layers.flatMap { listOf(it.src, it.font) }.filter { it.isNotEmpty() }.toSet().forEach { n ->
                val f = File(Assets.dir(c), n)
                if (f.exists()) { z.putNextEntry(ZipEntry("assets/$n")); z.write(f.readBytes()); z.closeEntry() }
            }
        }
    }
}

/**
 * Conversor de presets KWGT (preset.json) a diseños WidgetForge.
 *
 * Soporta: texto (con fórmulas Kustom), formas (rect, círculo, óvalo, triángulo, squircle), imágenes, barras/arcos de progreso,
 * grupos Overlap/Stack anidados con anclaje y desplazamiento, variables globales (gv), fuentes e imágenes del paquete.
 * Lo que no entiende no rompe la importación: se omite y queda listado en el informe.
 * Los widgets bloqueados por su autor (locked) vienen cifrados y se rechazan con un mensaje claro.
 */
object Kwgt {
    private class Built(val w: Float, val h: Float, val add: (Float, Float) -> Unit)

    private class Imp(val c: Context, val files: Map<String, ByteArray>, val d: Design) {
        val used = HashSet<String>()
        val ignored = LinkedHashSet<String>()
        val frozen = LinkedHashSet<String>()
        val badFn = LinkedHashSet<String>()
        val warn = LinkedHashSet<String>()
        val unsupported = LinkedHashMap<String, Int>()

        // ---------- lectura de propiedades (admite varios nombres de clave y fórmulas) ----------
        fun rawKey(o: JSONObject, vararg k: String): String? {
            for (x in k) if (o.has(x) && !o.isNull(x)) return x
            return null
        }

        fun str(o: JSONObject, def: String, vararg k: String): String {
            val key = rawKey(o, *k) ?: return def
            used.add(key)
            return o.get(key).toString()
        }

        fun num(o: JSONObject, def: Float, vararg k: String): Float {
            val key = rawKey(o, *k) ?: return def
            used.add(key)
            val v = o.get(key)
            if (v is Number) return v.toFloat()
            val s = v.toString().trim()
            if (s.contains('$')) {
                frozen.add(key); badFn.addAll(Formula.unsupportedIn(s))
                return Vars.resolve(c, s, d.globals).trim().toFloatOrNull() ?: def
            }
            return s.toFloatOrNull() ?: def
        }

        fun col(o: JSONObject, def: Int, vararg k: String): Int {
            val key = rawKey(o, *k) ?: return def
            used.add(key)
            val v = o.get(key)
            if (v is Number) return v.toInt()
            var s = v.toString().trim()
            if (s.contains('$')) {
                frozen.add(key); badFn.addAll(Formula.unsupportedIn(s))
                s = Vars.resolve(c, s, d.globals).trim()
            }
            return try { Color.parseColor(s) } catch (e: Exception) { def }
        }

        fun anchor(o: JSONObject): Pair<Float, Float> {
            val a = str(o, "CENTER", "position_anchor").uppercase()
            val fx = if (a.contains("LEFT")) 0f else if (a.contains("RIGHT")) 1f else 0.5f
            val fy = if (a.startsWith("TOP")) 0f else if (a.startsWith("BOTTOM")) 1f else 0.5f
            return Pair(fx, fy)
        }

        // ---------- recursos del paquete (kfile://org.kustom.provider/fonts/x.ttf, .../bitmaps/IMG...) ----------
        fun findFile(ref: String): Pair<String, ByteArray>? {
            val name = Uri.decode(ref.substringAfterLast('/')) ?: return null
            if (name.isEmpty()) return null
            for ((k, v) in files) {
                val kn = (Uri.decode(k) ?: k).substringAfterLast('/')
                if (kn.equals(name, ignoreCase = true)) return Pair(kn, v)
            }
            return null
        }

        fun store(name: String, data: ByteArray): String {
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val fn = "kw_${data.size}_$safe"
            val f = File(Assets.dir(c), fn)
            if (!f.exists()) f.writeBytes(data)
            return fn
        }

        fun account(o: JSONObject) {
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                if (k !in used && !k.startsWith("internal_") && k != "viewgroup_items") ignored.add(k)
            }
        }

        fun globals(root: JSONObject) {
            val g = root.opt("internal_globals")
            if (g is JSONArray) {
                for (i in 0 until g.length()) {
                    val x = g.optJSONObject(i) ?: continue
                    val n = x.optString("id", "").ifEmpty { x.optString("name", "").ifEmpty { x.optString("title", "") } }
                    if (n.isNotEmpty()) d.globals[n] = x.opt("value")?.toString() ?: ""
                }
            } else if (g is JSONObject) {
                val ks = g.keys()
                while (ks.hasNext()) { val k = ks.next(); d.globals[k] = g.opt(k)?.toString() ?: "" }
            }
        }

        // ---------- disposición ----------
        fun walk(node: JSONObject, px: Float, py: Float, pw: Float, ph: Float, mode: Int, spacing: Float) {
            val items = node.optJSONArray("viewgroup_items") ?: return
            var cursor = 0f
            for (i in 0 until items.length()) {
                val o = items.optJSONObject(i) ?: continue
                if (o.optBoolean("internal_hidden", false)) continue
                val type = o.optString("internal_type")
                val b = prepare(o, type, pw, ph, true)
                val a = anchor(o)
                val fx = a.first; val fy = a.second
                val ox = num(o, 0f, "position_offset_x")
                val oy = num(o, 0f, "position_offset_y")
                account(o)
                if (b == null) continue
                var left: Float
                var top: Float
                when (mode) {
                    1 -> { left = px + cursor + ox; top = py + (ph - b.h) / 2f + oy; cursor += b.w + spacing }
                    2 -> { left = px + (pw - b.w) / 2f + ox; top = py + cursor + oy; cursor += b.h + spacing }
                    else -> { left = px + pw * fx + ox - b.w * fx; top = py + ph * fy + oy - b.h * fy }
                }
                b.add(left, top)
            }
        }

        fun prepare(o: JSONObject, type: String, pw: Float, ph: Float, count: Boolean): Built? = when (type) {
            "TextModule" -> text(o)
            "ShapeModule" -> shape(o)
            "BitmapModule" -> bitmap(o)
            "ProgressModule" -> progress(o)
            else -> if (o.has("viewgroup_items")) group(o, type, pw, ph) else {
                if (count) unsupported[type] = (unsupported[type] ?: 0) + 1
                null
            }
        }

        fun group(o: JSONObject, type: String, pw: Float, ph: Float): Built {
            var mode = 0
            var sp = 0f
            if (type.contains("Stack", ignoreCase = true)) {
                mode = if (str(o, "HORIZONTAL", "stack_mode", "layer_stack_mode").uppercase().contains("VERT")) 2 else 1
                sp = num(o, 0f, "stack_spacing", "stack_margin")
                warn.add("Grupos Stack: disposición aproximada")
            }
            var w = num(o, -1f, "position_width", "layer_width", "background_width", "viewgroup_width")
            var h = num(o, -1f, "position_height", "layer_height", "background_height", "viewgroup_height")
            if (w < 0f || h < 0f) {
                var sw = 0f
                var sh = 0f
                val items = o.optJSONArray("viewgroup_items")
                if (mode != 0 && items != null) {
                    for (i in 0 until items.length()) {
                        val ch = items.optJSONObject(i) ?: continue
                        val bb = prepare(ch, ch.optString("internal_type"), pw, ph, false) ?: continue
                        if (mode == 1) { sw += bb.w + sp; sh = maxOf(sh, bb.h) } else { sh += bb.h + sp; sw = maxOf(sw, bb.w) }
                    }
                }
                if (w < 0f) w = if (mode != 0) sw else pw
                if (h < 0f) h = if (mode != 0) sh else ph
            }
            val gw = w; val gh = h; val gm = mode; val gs = sp
            return Built(gw, gh) { l, t -> walk(o, l, t, gw, gh, gm, gs) }
        }

        // ---------- módulos ----------
        fun text(o: JSONObject): Built {
            val size = num(o, 20f, "text_size")
            val raw = str(o, "\$df(HH:mm)\$", "text_expression")
            badFn.addAll(Formula.unsupportedIn(raw))
            val ff = findFile(str(o, "", "text_family"))
            val font = if (ff != null) store(ff.first, ff.second) else ""
            val tf = if (font.isNotEmpty()) Assets.typeface(c, font) else null
            val cs = str(o, "", "text_case", "text_transform").uppercase()
            val tcase = if (cs.contains("UP")) 1 else if (cs.contains("LOW")) 2 else if (cs.contains("TITLE") || cs.contains("CAP")) 3 else 0
            val stroked = str(o, "FILL", "paint_style").uppercase() == "STROKE"
            val color = col(o, -1, "paint_color")
            val sw = num(o, 1f, "paint_stroke")
            val rot = num(o, 0f, "fx_rotate_offset", "position_rotation", "rotate_offset")
            val ta = str(o, "", "text_align").uppercase()
            val fx = anchor(o).first
            val align = when {
                ta.contains("LEFT") -> 0
                ta.contains("RIGHT") -> 2
                ta.contains("CENTER") -> 1
                fx == 0f -> 0
                fx == 1f -> 2
                else -> 1
            }
            val lines = Vars.resolve(c, raw, d.globals).split("\n")
            val pt = Paint()
            pt.textSize = size
            pt.typeface = tf
            val w = maxOf(lines.maxOf { pt.measureText(it) }, 1f)
            val fm = pt.fontMetrics
            val h = (fm.descent - fm.ascent) + size * 1.2f * (lines.size - 1)
            return Built(w, h) { left, top ->
                d.layers += Layer(
                    type = "text", text = raw, x = left, y = top - fm.ascent - size, w = w, size = size, font = font,
                    color = if (stroked) 0 else color, stroke = if (stroked) sw else 0f,
                    strokeColor = if (stroked) color else 0x99FFFFFF.toInt(), align = align, rot = rot, textCase = tcase
                )
            }
        }

        fun shape(o: JSONObject): Built {
            val st = str(o, "RECT", "shape_type", "shape_shape", "background_shape").uppercase()
            val w = num(o, 100f, "shape_width", "background_width", "shape_size")
            val h = num(o, w, "shape_height", "background_height")
            val corners = num(o, 0f, "shape_corners", "background_corners", "shape_radius")
            val color = col(o, -1, "paint_color")
            val stroked = str(o, "FILL", "paint_style").uppercase() == "STROKE"
            val sw = num(o, 1f, "paint_stroke")
            val rot = num(o, 0f, "fx_rotate_offset", "position_rotation", "rotate_offset")
            var type = "rect"
            var rad = corners
            when {
                st.contains("CIRCLE") || st.contains("OVAL") -> type = "circle"
                st.contains("TRIANGLE") -> type = "triangle"
                st.contains("SQUIRCLE") -> rad = minOf(w, h) * 0.3f
                st.contains("RECT") || st.contains("SQUARE") -> {}
                else -> warn.add("Forma $st: se dibuja como rectángulo")
            }
            val ft = type; val fr = rad
            return Built(w, h) { left, top ->
                d.layers += Layer(
                    type = ft, x = left, y = top, w = w, h = h, radius = fr,
                    color = if (stroked) 0 else color, stroke = if (stroked) sw else 0f,
                    strokeColor = if (stroked) color else 0x99FFFFFF.toInt(), rot = rot
                )
            }
        }

        fun bitmap(o: JSONObject): Built? {
            val ref = str(o, "", "bitmap_bitmap")
            val ff = findFile(ref)
            if (ff == null) {
                warn.add("Imagen no encontrada en el archivo: ${ref.substringAfterLast('/')}")
                return null
            }
            val fn = store(ff.first, ff.second)
            val opt = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(ff.second, 0, ff.second.size, opt)
            val iw = opt.outWidth.coerceAtLeast(1).toFloat()
            val ih = opt.outHeight.coerceAtLeast(1).toFloat()
            var w = num(o, -1f, "bitmap_width", "bitmap_size")
            var h = num(o, -1f, "bitmap_height", "bitmap_size")
            if (w <= 0f && h <= 0f) { w = iw; h = ih } else if (w <= 0f) w = h * iw / ih else if (h <= 0f) h = w * ih / iw
            val rot = num(o, 0f, "fx_rotate_offset", "position_rotation", "rotate_offset")
            val fw = w; val fh = h
            return Built(fw, fh) { left, top ->
                d.layers += Layer(type = "image", src = fn, x = left, y = top, w = fw, h = fh, radius = 0f, rot = rot)
            }
        }

        fun progress(o: JSONObject): Built {
            val mode = str(o, "CIRCLE", "progress_mode").uppercase()
            val w = num(o, 100f, "progress_width", "shape_width", "background_width")
            val h = num(o, w, "progress_height", "shape_height", "background_height")
            val lvl = str(o, "50", "progress_level", "progress_expression", "progress_value")
            badFn.addAll(Formula.unsupportedIn(lvl))
            val thick = num(o, 12f, "progress_arc_width", "progress_stroke", "paint_stroke")
            val color = col(o, -1, "paint_color")
            val circular = mode.contains("CIRC") || mode.contains("ARC")
            warn.add("Barras/arcos de progreso: tamaño y grosor aproximados")
            return Built(w, h) { left, top ->
                d.layers += if (circular)
                    Layer(type = "arc", x = left, y = top, w = w, h = h, color = color, size = thick, progress = lvl)
                else
                    Layer(type = "bar", x = left, y = top, w = w, h = h, color = color, radius = h / 2f, progress = lvl)
            }
        }
    }

    fun convert(c: Context, root: JSONObject, files: Map<String, ByteArray>): ImportResult {
        val info = root.optJSONObject("preset_info") ?: JSONObject()
        val rootNode = root.optJSONObject("preset_root") ?: JSONObject()
        val title = info.optString("title", "").ifEmpty { "KWGT" }
        val items = rootNode.optJSONArray("viewgroup_items")
        val locked = info.optBoolean("locked", false) || rootNode.has("internal_readonly")

        if (locked && (items == null || items.length() == 0)) {
            return ImportResult(
                null, error = "«$title» está bloqueado por su autor (locked): el contenido va cifrado dentro del archivo " +
                    "y solo KWGT puede leerlo. Pide al autor la versión sin bloquear."
            )
        }

        val w = info.optDouble("width", 0.0).toFloat().let { if (it > 0f) it else 400f }
        val h = info.optDouble("height", 0.0).toFloat().let { if (it > 0f) it else 200f }
        val d = Design(name = title, w = w, h = h, bg = 0, radius = 0f)
        val imp = Imp(c, files, d)
        imp.globals(rootNode)
        d.bg = imp.col(rootNode, 0, "background_color")
        imp.walk(rootNode, 0f, 0f, w, h, 0, 0f)

        val notes = ArrayList<String>()
        notes.add("${d.layers.size} capas · ${w.toInt()}×${h.toInt()}")
        if (locked) notes.add("Marcado como bloqueado: puede faltar contenido")
        if (imp.unsupported.isNotEmpty())
            notes.add("Módulos no soportados (omitidos): " + imp.unsupported.entries.joinToString { "${it.key} ×${it.value}" })
        if (imp.badFn.isNotEmpty())
            notes.add("Fórmulas sin soporte (salen vacías): " + imp.badFn.joinToString { "$it()" })
        if (imp.frozen.isNotEmpty())
            notes.add("Valores dinámicos fijados (sin animación): " + imp.frozen.take(8).joinToString())
        notes.addAll(imp.warn.take(6))
        if (imp.ignored.isNotEmpty())
            notes.add("Propiedades ignoradas: " + imp.ignored.take(15).joinToString() + if (imp.ignored.size > 15) "…" else "")
        if (d.layers.isEmpty()) notes.add("No se importó ninguna capa")
        return ImportResult(d, notes)
    }
}
