package com.animevault.app.domain.usecase

import com.animevault.app.domain.model.*
import com.animevault.app.domain.repository.*

class SearchAnimeUseCase(private val repo: ContentRepository) {
    suspend operator fun invoke(query: String): AppResult<List<Anime>> = repo.search(query)
}

class GetAnimeDetailUseCase(private val repo: ContentRepository) {
    suspend operator fun invoke(id: String): AppResult<Anime> = repo.detail(id)
}

class TestContentConnectionUseCase(private val repo: ContentRepository) {
    suspend operator fun invoke(config: ContentConfig): AppResult<String> = repo.testConnection(config)
}

class TestDownloadConnectionUseCase(private val repo: DownloadRepository) {
    suspend operator fun invoke(config: DownloadConfig): AppResult<String> = repo.testConnection(config)
}

class ObserveSettingsUseCase(repo: SettingsRepository) {
    val content = repo.contentConfig
    val download = repo.downloadConfig
}

class SaveSettingsUseCase(private val repo: SettingsRepository) {
    suspend fun content(config: ContentConfig) = repo.saveContent(config)
    suspend fun download(config: DownloadConfig) = repo.saveDownload(config)
}

class MyListUseCases(private val repo: MyListRepository) {
    fun observeAll() = repo.observeAll()
    fun observe(id: String) = repo.observe(id)
    suspend fun setStatus(anime: Anime, status: ListStatus?) = repo.setStatus(anime, status)
    suspend fun toggleFavorite(anime: Anime) = repo.toggleFavorite(anime)
    suspend fun remove(id: String) = repo.remove(id)
}

class DownloadUseCases(private val repo: DownloadRepository) {
    fun observeAll() = repo.observeAll()
    suspend fun enqueue(animeId: String, title: String): AppResult<Unit> = repo.enqueue(animeId, title)
    suspend fun pause(id: Long) = repo.pause(id)
    suspend fun resume(id: Long) = repo.resume(id)
    suspend fun remove(id: Long) = repo.remove(id)
}
