package com.animevault.app.presentation.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: SettingsViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text(
            "Las dos APIs son independientes y se guardan solo en tu dispositivo.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionCard("API de Contenido") {
            Field("Base URL", vm.cBase, { vm.cBase = it }, placeholder = "https://")
            Field("API Key (opcional)", vm.cKey, { vm.cKey = it }, secret = true, keyboard = KeyboardType.Password)
            Field(
                "Endpoint de búsqueda", vm.cSearch, { vm.cSearch = it }, placeholder = "/anime?q=",
                supporting = "Se añade lo que escribas al final. O usa {q} para colocarlo donde quieras."
            )
            Field("Endpoint de detalle", vm.cDetail, { vm.cDetail = it }, placeholder = "/anime/{id}")
            Actions(vm.contentSaved, vm::saveContent, vm::testContent)
            TestResult(vm.contentTest)
        }

        SectionCard("API de Descargas") {
            Field("Base URL de descargas", vm.dBase, { vm.dBase = it }, placeholder = "https://")
            Field("API Key de descargas (opcional)", vm.dKey, { vm.dKey = it }, secret = true, keyboard = KeyboardType.Password)
            Field(
                "Endpoint de descarga", vm.dEndpoint, { vm.dEndpoint = it }, placeholder = "/download/{id}",
                supporting = "Puede devolver el archivo directo o un JSON con el enlace. También acepta {title}."
            )
            Actions(vm.downloadSaved, vm::saveDownload, vm::testDownload)
            TestResult(vm.downloadTest)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String? = null,
    supporting: String? = null,
    secret: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Uri
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = placeholder?.let { { Text(it) } },
        supportingText = supporting?.let { { Text(it) } },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        visualTransformation = if (secret && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = if (secret) {
            { TextButton(onClick = { visible = !visible }) { Text(if (visible) "Ocultar" else "Ver") } }
        } else null,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun Actions(saved: Boolean, onSave: () -> Unit, onTest: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onSave, modifier = Modifier.weight(1f)) { Text(if (saved) "✓ Guardado" else "Guardar") }
        OutlinedButton(onClick = onTest, modifier = Modifier.weight(1f)) { Text("Probar conexión") }
    }
}

@Composable
private fun TestResult(state: TestState) {
    when (state) {
        TestState.Idle -> {}
        TestState.Running -> Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(8.dp))
            Text("Probando…")
        }
        is TestState.Done -> Text(
            state.message,
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(if (state.ok) Color(0x3329C76F) else Color(0x33FF6B6B))
                .padding(12.dp)
        )
    }
}
