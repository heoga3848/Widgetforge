package com.animevault.app.data.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.animevault.app.AnimeVaultApp
import com.animevault.app.data.local.db.DownloadDao
import com.animevault.app.data.local.db.DownloadEntity
import com.animevault.app.data.remote.Http
import com.animevault.app.domain.model.DownloadConfig
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.coroutines.coroutineContext

class DownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_ID = "download_id"
        private const val CHANNEL = "downloads"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id = inputData.getLong(KEY_ID, -1L)
        val container = (applicationContext as AnimeVaultApp).container
        val dao = container.database.downloadDao()
        val entity = dao.get(id) ?: return@withContext Result.success()
        if (dao.markRunning(id) == 0) return@withContext Result.success()
        try {
            foreground(id, entity.title, 0)
            transfer(container.settings.downloadConfig.first(), dao, id, entity)
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            dao.fail(id, Http.describeError(e))
            Result.failure()
        }
    }

    private suspend fun transfer(cfg: DownloadConfig, dao: DownloadDao, id: Long, e: DownloadEntity) {
        if (!cfg.isConfigured) throw IOException("Configura tu API de Descargas en Ajustes")
        val base = Http.normalizeBase(cfg.baseUrl).toHttpUrlOrNull()
            ?: throw IOException("La Base URL de descargas no es válida")
        val endpoint = Http.relative(
            cfg.downloadEndpoint.replace("{id}", Uri.encode(e.animeId)).replace("{title}", Uri.encode(e.title))
        )
        val entryUrl = base.resolve(endpoint) ?: throw IOException("El endpoint de descarga no es válido")

        var file: File? = e.filePath?.let { File(it) }
        var existing: Long = file?.takeIf { it.exists() }?.length() ?: 0L

        fun get(url: HttpUrl): Response {
            var r = open(url, cfg, base, existing)
            if (r.code == 416 && existing > 0) {
                r.close(); file?.delete(); existing = 0L
                r = open(url, cfg, base, 0L)
            }
            return r
        }

        var response = get(entryUrl)
        if (!response.isSuccessful) failWith(response)

        val ct = response.header("Content-Type").orEmpty().lowercase()
        if (ct.contains("json")) {
            val text = response.body?.string().orEmpty()
            response.close()
            val link = LinkExtractor.find(text)
                ?: throw IOException("La API de Descargas respondió JSON sin enlace de archivo:\n${text.take(200)}")
            val fileUrl = base.resolve(link) ?: throw IOException("Enlace de descarga inválido: $link")
            response = get(fileUrl)
            if (!response.isSuccessful) failWith(response)
        }

        response.use { resp ->
            val body = resp.body ?: throw IOException("Respuesta vacía del servidor")
            val partial = resp.code == 206 && existing > 0
            val total: Long = if (partial) {
                resp.header("Content-Range")?.substringAfter("/", "")?.toLongOrNull() ?: -1L
            } else body.contentLength()

            if (file == null) {
                file = makeFile(e, resp)
                dao.setPath(id, file!!.path)
            }
            val target = file!!
            var downloaded = if (partial) existing else 0L
            val buf = ByteArray(64 * 1024)
            var lastTs = SystemClock.elapsedRealtime()
            var lastBytes = downloaded
            var lastFg = lastTs

            body.byteStream().use { input ->
                FileOutputStream(target, partial).use { out ->
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        downloaded += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTs >= 500) {
                            val speed = (downloaded - lastBytes) * 1000 / (now - lastTs)
                            dao.progress(id, downloaded, total, speed)
                            if (now - lastFg >= 1000) {
                                foreground(id, e.title, if (total > 0) (downloaded * 100 / total).toInt() else -1)
                                lastFg = now
                            }
                            lastTs = now
                            lastBytes = downloaded
                        }
                    }
                }
            }
            if (total > 0 && downloaded < total) throw IOException("Descarga incompleta (se cortó la conexión)")
            dao.complete(id, target.length())
        }
    }

    private fun open(url: HttpUrl, cfg: DownloadConfig, base: HttpUrl, from: Long): Response {
        val b = Request.Builder().url(url)
        if (url.host == base.host) Http.authHeaders(cfg.apiKey).forEach { (k, v) -> b.header(k, v) }
        if (from > 0) b.header("Range", "bytes=$from-")
        return Http.client.newCall(b.build()).execute()
    }

    private fun failWith(resp: Response): Nothing {
        val msg = resp.body?.string()?.take(200).orEmpty()
        val code = resp.code
        resp.close()
        throw IOException("HTTP $code $msg".trim())
    }

    private fun makeFile(e: DownloadEntity, resp: Response): File {
        val dir = applicationContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: applicationContext.filesDir
        dir.mkdirs()
        val safe = e.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100).ifBlank { "anime" }
        val ext = extensionFor(resp)
        var f = File(dir, "$safe.$ext")
        if (f.exists()) f = File(dir, "$safe (${e.id}).$ext")
        return f
    }

    private fun extensionFor(resp: Response): String {
        resp.header("Content-Disposition")?.let { cd ->
            Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
                ?.groupValues?.get(1)?.substringAfterLast('.', "")
                ?.takeIf { it.length in 2..5 }?.let { return it.lowercase() }
        }
        resp.request.url.encodedPath.substringAfterLast('/').substringAfterLast('.', "")
            .takeIf { it.length in 2..4 && it.all(Char::isLetterOrDigit) }?.let { return it.lowercase() }
        val ct = resp.header("Content-Type").orEmpty().lowercase()
        return when {
            ct.contains("matroska") -> "mkv"
            ct.contains("webm") -> "webm"
            ct.contains("zip") -> "zip"
            else -> "mp4"
        }
    }

    private suspend fun foreground(id: Long, title: String, percent: Int) {
        try {
            setForeground(foregroundInfo(id, title, percent))
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private fun foregroundInfo(id: Long, title: String, percent: Int): ForegroundInfo {
        val ctx = applicationContext
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Descargas", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(if (percent >= 0) "$percent%" else "Descargando…")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, maxOf(percent, 0), percent < 0)
            .build()
        val nid = (1000 + id).toInt()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(nid, n)
    }
}

object LinkExtractor {
    private val KEYS = listOf("download_url", "downloadUrl", "direct_link", "directLink", "url", "link", "file", "href", "src", "download")

    fun find(json: String): String? = runCatching { search(JsonParser.parseString(json), 0) }.getOrNull()

    private fun search(e: JsonElement, depth: Int): String? {
        if (e.isJsonPrimitive) {
            val s = e.asString
            return if (s.startsWith("http", true) || s.startsWith("/")) s else null
        }
        if (depth >= 4) return null
        if (e.isJsonObject) {
            val o = e.asJsonObject
            for (k in KEYS) {
                val v = o.get(k) ?: continue
                search(v, depth + 1)?.let { return it }
            }
            for ((_, v) in o.entrySet()) search(v, depth + 1)?.let { return it }
        } else if (e.isJsonArray) {
            for (v in e.asJsonArray) search(v, depth + 1)?.let { return it }
        }
        return null
    }
}
