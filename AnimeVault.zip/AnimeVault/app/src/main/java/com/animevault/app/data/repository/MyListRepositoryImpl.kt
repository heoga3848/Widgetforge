package com.animevault.app.data.repository

import com.animevault.app.data.local.db.MyListDao
import com.animevault.app.data.local.db.MyListEntity
import com.animevault.app.data.local.db.toDomain
import com.animevault.app.domain.model.Anime
import com.animevault.app.domain.model.ListEntry
import com.animevault.app.domain.model.ListStatus
import com.animevault.app.domain.repository.MyListRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MyListRepositoryImpl(private val dao: MyListDao) : MyListRepository {

    override fun observeAll(): Flow<List<ListEntry>> = dao.observeAll().map { l -> l.map { it.toDomain() } }

    override fun observe(animeId: String): Flow<ListEntry?> = dao.observe(animeId).map { it?.toDomain() }

    override suspend fun setStatus(anime: Anime, status: ListStatus?) {
        val cur = dao.get(anime.id)
        apply(anime, status, cur?.favorite ?: false)
    }

    override suspend fun toggleFavorite(anime: Anime) {
        val cur = dao.get(anime.id)
        val status = cur?.status?.let { runCatching { ListStatus.valueOf(it) }.getOrNull() }
        apply(anime, status, !(cur?.favorite ?: false))
    }

    override suspend fun remove(animeId: String) = dao.delete(animeId)

    private suspend fun apply(a: Anime, status: ListStatus?, favorite: Boolean) {
        if (status == null && !favorite) dao.delete(a.id)
        else dao.upsert(MyListEntity(a.id, a.title, a.coverUrl, a.score, status?.name, favorite, System.currentTimeMillis()))
    }
}
