# AnimeVault (uso privado)

1. Abre la carpeta en Android Studio (Ladybug o más nuevo) y espera el Gradle Sync.
2. Run ▶ en tu teléfono (o genera APK: Build > Build APK).
3. Ajustes > API de Contenido: Base URL, API Key (opcional), endpoint de búsqueda (/anime?q=) y de detalle (/anime/{id}). Guardar > Probar conexión.
4. Ajustes > API de Descargas: Base URL, API Key (opcional), endpoint (/download/{id}). Guardar > Probar conexión.
5. Busca un anime, entra al detalle y pulsa Descargar.

Descargas guardadas en: Android/data/com.animevault.app/files/Download/
