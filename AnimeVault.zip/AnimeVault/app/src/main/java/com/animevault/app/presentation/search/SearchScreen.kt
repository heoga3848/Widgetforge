package com.animevault.app.presentation.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.animevault.app.presentation.components.*

@Composable
fun SearchScreen(vm: SearchViewModel, onOpenDetail: (String) -> Unit, onOpenSettings: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val configured by vm.configured.collectAsStateWithLifecycle()
    val focus: FocusManager = LocalFocusManager.current

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Descubre", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("Tu anime, a tu manera", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar anime…") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(50),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.search() })
            )
        }
        if (!configured) {
            NoticeCard(
                "Configura tu API de Contenido en Ajustes",
                Modifier.padding(horizontal = 16.dp),
                actionLabel = "Ir a Ajustes",
                onAction = onOpenSettings
            )
        }
        when (val s = state) {
            SearchUiState.Idle -> if (configured) CenterHint("Escribe el nombre de un anime y pulsa buscar")
            SearchUiState.Loading -> CenterLoading()
            SearchUiState.Empty -> CenterHint("Sin resultados")
            is SearchUiState.Error -> NoticeCard(
                s.message,
                Modifier.padding(16.dp),
                isError = true,
                actionLabel = "Reintentar",
                onAction = vm::search
            )
            is SearchUiState.Success -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(s.items) { a ->
                    AnimeCard(a.title, a.coverUrl, a.score, onClick = { onOpenDetail(a.id) })
                }
            }
        }
    }
}
