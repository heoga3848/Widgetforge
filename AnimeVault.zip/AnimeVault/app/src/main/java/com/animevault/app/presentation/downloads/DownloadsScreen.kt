package com.animevault.app.presentation.downloads

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.animevault.app.domain.model.DownloadItem
import com.animevault.app.domain.model.DownloadState
import com.animevault.app.presentation.components.CenterHint
import com.animevault.app.presentation.components.NoticeCard
import java.io.File

@Composable
fun DownloadsScreen(vm: DownloadsViewModel, onOpenSettings: () -> Unit) {
    val items by vm.items.collectAsStateWithLifecycle()
    val configured by vm.configured.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf<DownloadItem?>(null) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Descargas",
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold
        )
        if (!configured) {
            NoticeCard(
                "Configura tu API de Descargas en Ajustes",
                Modifier.padding(horizontal = 16.dp),
                actionLabel = "Ir a Ajustes",
                onAction = onOpenSettings
            )
        }
        if (items.isEmpty()) {
            CenterHint("No hay descargas todavía")
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(items, key = { it.id }) { item ->
                    DownloadCard(
                        item,
                        onPause = { vm.pause(item.id) },
                        onResume = { vm.resume(item.id) },
                        onCancel = { confirm = item },
                        onOpen = { item.filePath?.let { openFile(ctx, it) } },
                        onDelete = { confirm = item }
                    )
                }
            }
        }
    }

    confirm?.let { item ->
        val done = item.state == DownloadState.COMPLETED
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (done) "Borrar archivo" else "Cancelar descarga") },
            text = { Text(item.title) },
            confirmButton = {
                TextButton(onClick = { vm.remove(item.id); confirm = null }) { Text(if (done) "Borrar" else "Cancelar descarga") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Volver") } }
        )
    }
}

@Composable
private fun DownloadCard(
    item: DownloadItem,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    fun size(b: Long) = Formatter.formatShortFileSize(ctx, b)
    val progress: Float? = if (item.totalBytes > 0) (item.downloadedBytes.toFloat() / item.totalBytes).coerceIn(0f, 1f) else null
    val pct = progress?.let { (it * 100).toInt() }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(item.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)

        if (item.state == DownloadState.COMPLETED) {
            val bytes = item.filePath?.let { File(it) }?.takeIf { it.exists() }?.length() ?: item.totalBytes
            Text("Completado · ${size(bytes)}", color = MaterialTheme.colorScheme.primary)
        } else {
            val bar = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50))
            if (progress != null) LinearProgressIndicator(progress = { progress }, modifier = bar)
            else LinearProgressIndicator(modifier = bar)

            val info = when (item.state) {
                DownloadState.QUEUED -> "En cola…"
                DownloadState.RUNNING -> buildString {
                    append(pct?.let { "$it%" } ?: "…")
                    append(" · ${size(item.downloadedBytes)}")
                    if (item.totalBytes > 0) append(" / ${size(item.totalBytes)}")
                    append(" · ${size(item.speedBps)}/s")
                }
                DownloadState.PAUSED -> "Pausado · ${pct?.let { "$it%" } ?: size(item.downloadedBytes)}"
                DownloadState.FAILED -> "Error: ${item.error ?: "desconocido"}"
                DownloadState.COMPLETED -> ""
            }
            Text(
                info,
                style = MaterialTheme.typography.bodySmall,
                color = if (item.state == DownloadState.FAILED) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            when (item.state) {
                DownloadState.QUEUED, DownloadState.RUNNING -> {
                    FilledTonalButton(onClick = onPause) { Icon(Icons.Rounded.Pause, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Pausar") }
                    OutlinedButton(onClick = onCancel) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Cancelar") }
                }
                DownloadState.PAUSED, DownloadState.FAILED -> {
                    FilledTonalButton(onClick = onResume) {
                        Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                        Text(if (item.state == DownloadState.FAILED) "Reintentar" else "Reanudar")
                    }
                    OutlinedButton(onClick = onCancel) { Icon(Icons.Rounded.Close, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Cancelar") }
                }
                DownloadState.COMPLETED -> {
                    FilledTonalButton(onClick = onOpen) { Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Abrir") }
                    OutlinedButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Borrar") }
                }
            }
        }
    }
}

private fun openFile(context: Context, path: String) {
    val file = File(path)
    if (!file.exists()) {
        Toast.makeText(context, "El archivo ya no existe", Toast.LENGTH_SHORT).show(); return
    }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No hay una app para abrir este archivo", Toast.LENGTH_LONG).show()
    }
}
