package com.animevault.app.domain.repository

import com.animevault.app.domain.model.*
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val contentConfig: Flow<ContentConfig>
    val downloadConfig: Flow<DownloadConfig>
    suspend fun saveContent(config: ContentConfig)
    suspend fun saveDownload(config: DownloadConfig)
}

interface ContentRepository {
    suspend fun search(query: String): AppResult<List<Anime>>
    suspend fun detail(id: String): AppResult<Anime>
    suspend fun testConnection(config: ContentConfig): AppResult<String>
}

interface MyListRepository {
    fun observeAll(): Flow<List<ListEntry>>
    fun observe(animeId: String): Flow<ListEntry?>
    suspend fun setStatus(anime: Anime, status: ListStatus?)
    suspend fun toggleFavorite(anime: Anime)
    suspend fun remove(animeId: String)
}

interface DownloadRepository {
    fun observeAll(): Flow<List<DownloadItem>>
    suspend fun enqueue(animeId: String, title: String): AppResult<Unit>
    suspend fun pause(id: Long)
    suspend fun resume(id: Long)
    suspend fun remove(id: Long)
    suspend fun testConnection(config: DownloadConfig): AppResult<String>
}
