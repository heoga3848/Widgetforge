package com.example.widgetforge

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID)
            setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize().systemBarsPadding()) { App(wid) } } }
    }

    fun finishPick(wid: Int, d: Design) {
        Store.assign(this, wid, d.id)
        WidgetForgeProvider.update(this, AppWidgetManager.getInstance(this), wid)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid)); finish()
    }
}

@Composable
fun App(wid: Int) {
    val ctx = LocalContext.current as MainActivity
    val picking = wid != AppWidgetManager.INVALID_APPWIDGET_ID
    var designs by remember { mutableStateOf(Store.list(ctx)) }
    var editing by remember { mutableStateOf<Design?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching {
                val d = Design.from(JSONObject(ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText()))
                d.id = UUID.randomUUID().toString(); Store.save(ctx, d); designs = Store.list(ctx)
            }
        }
    }
    val e = editing
    if (e != null) { Editor(e) { editing = null; designs = Store.list(ctx) }; return }
    Column(Modifier.padding(12.dp)) {
        Text(if (picking) "Elige un diseño para este widget" else "WidgetForge", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Store.templates().forEach { t -> TextButton({ editing = t }) { Text("+ ${t.name}") } }
            TextButton({ importer.launch(arrayOf("*/*")) }) { Text("Importar") }
        }
        LazyColumn {
            items(designs, key = { it.id }) { d ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        val bmp = remember(d.id, designs) { Renderer.render(ctx, d, 1f) }
                        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(d.w / d.h))
                        Text(d.name)
                        Row {
                            if (picking) Button({ ctx.finishPick(wid, d) }) { Text("Usar") }
                            TextButton({ editing = d }) { Text("Editar") }
                            TextButton({ Store.delete(ctx, d); designs = Store.list(ctx) }) { Text("Borrar") }
                        }
                    }
                }
            }
        }
    }
}

private val PRESETS = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFFF3B30, 0xFF00F2FF, 0xFFFF00E5, 0xFFFFD60A, 0xFF00FF88, 0x00000000, 0xCC101018
).map { it.toInt() }

@Composable
fun Colors(onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        PRESETS.forEach { c -> Box(Modifier.padding(4.dp).size(36.dp).background(Color(c)).border(1.dp, Color.Gray).clickable { onPick(c) }) }
    }
}

@Composable
fun Sl(label: String, v: Float, range: ClosedFloatingPointRange<Float>, set: (Float) -> Unit) {
    Text("$label: ${v.toInt()}"); Slider(v.coerceIn(range), set, valueRange = range)
}

@Composable
fun Editor(d: Design, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    fun upd(f: () -> Unit) { f(); tick++ }
    val bmp = remember(tick) { Renderer.render(ctx, d, 1.5f) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(d.toJson().toString().toByteArray()) } }
    }
    val l = d.layers.getOrNull(sel)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().aspectRatio(d.w / d.h))
        OutlinedTextField(d.name, { upd { d.name = it } }, Modifier.fillMaxWidth(), label = { Text("Nombre") })
        Row {
            Button({ Store.save(ctx, d); onClose() }) { Text("Guardar") }
            TextButton(onClose) { Text("Salir") }
            TextButton({ exporter.launch("${d.name}.json") }) { Text("Exportar") }
        }
        Text("Fondo"); Colors { c -> upd { d.bg = c } }
        Sl("Esquinas", d.radius, 0f..200f) { upd { d.radius = it } }
        Text("Capas")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            d.layers.forEachIndexed { i, x -> FilterChip(sel == i, { sel = i }, { Text("${i + 1} ${x.type}") }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("text" to "+Texto", "rect" to "+Rect", "circle" to "+Círculo", "arc" to "+Arco").forEach { (t, n) ->
                TextButton({ upd { d.layers.add(Layer(type = t)); sel = d.layers.lastIndex } }) { Text(n) }
            }
        }
        if (l != null) {
            if (l.type == "text") {
                OutlinedTextField(l.text, { upd { l.text = it } }, Modifier.fillMaxWidth(), label = { Text("Texto ({hh} {mm} {date} {day} {battery}...)") })
                Row { Checkbox(l.bold, { upd { l.bold = it } }); Text("Negrita") }
                Sl("Tamaño", l.size, 8f..200f) { upd { l.size = it } }
            } else {
                Sl("Ancho", l.w, 0f..d.w) { upd { l.w = it } }
                Sl("Alto", l.h, 0f..d.h) { upd { l.h = it } }
                if (l.type == "rect") Sl("Esquinas", l.radius, 0f..200f) { upd { l.radius = it } }
            }
            if (l.type == "arc") {
                OutlinedTextField(l.progress, { upd { l.progress = it } }, Modifier.fillMaxWidth(), label = { Text("Progreso: battery, minute, hour, storage") })
                Sl("Grosor", l.size, 4f..80f) { upd { l.size = it } }
            }
            Sl("X", l.x, 0f..d.w) { upd { l.x = it } }
            Sl("Y", l.y, 0f..d.h) { upd { l.y = it } }
            Text("Color"); Colors { c -> upd { l.color = c } }
            TextButton({ upd { d.layers.removeAt(sel); sel = 0 } }) { Text("Borrar capa") }
        }
    }
}
