package com.animevault.app.presentation.mylist

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.animevault.app.domain.model.ListEntry
import com.animevault.app.domain.model.ListStatus
import com.animevault.app.presentation.components.CenterHint
import com.animevault.app.presentation.components.ScoreChip

@Composable
fun MyListScreen(vm: MyListViewModel, onOpenDetail: (String) -> Unit) {
    val items by vm.items.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        Text(
            "Mi Lista",
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold
        )
        ScrollableTabRow(
            selectedTabIndex = selected.ordinal,
            edgePadding = 16.dp,
            containerColor = Color.Transparent,
            divider = {}
        ) {
            ListTab.entries.forEach { t ->
                Tab(selected = t == selected, onClick = { vm.select(t) }, text = { Text(t.label) })
            }
        }
        if (items.isEmpty()) {
            CenterHint("Aún no hay nada aquí")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items) { e ->
                    EntryRow(
                        e,
                        onOpen = { onOpenDetail(e.animeId) },
                        onStatus = { vm.setStatus(e, it) },
                        onFavorite = { vm.toggleFavorite(e) },
                        onRemove = { vm.remove(e) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EntryRow(
    e: ListEntry,
    onOpen: () -> Unit,
    onStatus: (ListStatus) -> Unit,
    onFavorite: () -> Unit,
    onRemove: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onOpen)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = e.coverUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(64.dp)
                .height(92.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(e.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                e.score?.let { ScoreChip(it) }
                e.status?.let {
                    Text(it.label, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                }
                if (e.favorite) Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            }
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Opciones") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                ListStatus.entries.forEach { st ->
                    DropdownMenuItem(text = { Text("Mover a ${st.label}") }, onClick = { onStatus(st); menu = false })
                }
                DropdownMenuItem(
                    text = { Text(if (e.favorite) "Quitar de Favoritos" else "Añadir a Favoritos") },
                    onClick = { onFavorite(); menu = false }
                )
                DropdownMenuItem(text = { Text("Quitar de Mi Lista") }, onClick = { onRemove(); menu = false })
            }
        }
    }
}
