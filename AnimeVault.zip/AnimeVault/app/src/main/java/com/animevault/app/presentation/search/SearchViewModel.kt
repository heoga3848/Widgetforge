package com.animevault.app.presentation.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.animevault.app.domain.model.Anime
import com.animevault.app.domain.model.AppResult
import com.animevault.app.domain.usecase.ObserveSettingsUseCase
import com.animevault.app.domain.usecase.SearchAnimeUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    data object Idle : SearchUiState
    data object Loading : SearchUiState
    data object Empty : SearchUiState
    data class Error(val message: String) : SearchUiState
    data class Success(val items: List<Anime>) : SearchUiState
}

class SearchViewModel(
    private val searchAnime: SearchAnimeUseCase,
    observeSettings: ObserveSettingsUseCase
) : ViewModel() {

    var query by mutableStateOf("")

    private val _state = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    val configured: StateFlow<Boolean> = observeSettings.content.map { it.isConfigured }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    fun search() {
        if (query.isBlank()) return
        viewModelScope.launch {
            _state.value = SearchUiState.Loading
            _state.value = when (val r = searchAnime(query)) {
                is AppResult.Success -> if (r.data.isEmpty()) SearchUiState.Empty else SearchUiState.Success(r.data)
                is AppResult.Error -> SearchUiState.Error(r.message)
                AppResult.NotConfigured -> SearchUiState.Idle
            }
        }
    }
}
