package com.animevault.app.data.local.db

import androidx.room.*
import com.animevault.app.domain.model.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "my_list")
data class MyListEntity(
    @PrimaryKey val animeId: String,
    val title: String,
    val coverUrl: String?,
    val score: Double?,
    val status: String?,
    val favorite: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val animeId: String,
    val title: String,
    val state: String,
    val downloadedBytes: Long = 0,
    val totalBytes: Long = 0,
    val speedBps: Long = 0,
    val filePath: String? = null,
    val error: String? = null
)

fun MyListEntity.toDomain() = ListEntry(
    animeId = animeId,
    title = title,
    coverUrl = coverUrl,
    score = score,
    status = status?.let { runCatching { ListStatus.valueOf(it) }.getOrNull() },
    favorite = favorite
)

fun DownloadEntity.toDomain() = DownloadItem(
    id = id,
    animeId = animeId,
    title = title,
    state = DownloadState.valueOf(state),
    downloadedBytes = downloadedBytes,
    totalBytes = totalBytes,
    speedBps = speedBps,
    filePath = filePath,
    error = error
)

@Dao
interface MyListDao {
    @Query("SELECT * FROM my_list ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<MyListEntity>>

    @Query("SELECT * FROM my_list WHERE animeId = :id")
    fun observe(id: String): Flow<MyListEntity?>

    @Query("SELECT * FROM my_list WHERE animeId = :id")
    suspend fun get(id: String): MyListEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MyListEntity)

    @Query("DELETE FROM my_list WHERE animeId = :id")
    suspend fun delete(id: String)
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY id DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE animeId = :animeId LIMIT 1")
    suspend fun findByAnime(animeId: String): DownloadEntity?

    @Insert
    suspend fun insert(entity: DownloadEntity): Long

    @Query("UPDATE downloads SET state = :state, speedBps = 0 WHERE id = :id AND state IN (:from)")
    suspend fun transition(id: Long, state: String, from: List<String>): Int

    @Query("UPDATE downloads SET state = 'RUNNING', error = NULL WHERE id = :id AND state IN ('QUEUED','RUNNING')")
    suspend fun markRunning(id: Long): Int

    @Query("UPDATE downloads SET downloadedBytes = :downloaded, totalBytes = :total, speedBps = :speed WHERE id = :id AND state = 'RUNNING'")
    suspend fun progress(id: Long, downloaded: Long, total: Long, speed: Long)

    @Query("UPDATE downloads SET filePath = :path WHERE id = :id")
    suspend fun setPath(id: Long, path: String)

    @Query("UPDATE downloads SET state = 'COMPLETED', downloadedBytes = :size, totalBytes = :size, speedBps = 0 WHERE id = :id AND state = 'RUNNING'")
    suspend fun complete(id: Long, size: Long)

    @Query("UPDATE downloads SET state = 'FAILED', error = :message, speedBps = 0 WHERE id = :id AND state = 'RUNNING'")
    suspend fun fail(id: Long, message: String)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [MyListEntity::class, DownloadEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun myListDao(): MyListDao
    abstract fun downloadDao(): DownloadDao
}
