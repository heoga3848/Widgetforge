package com.example.widgetforge

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.SystemClock
import android.widget.RemoteViews

class WidgetForgeProvider : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }; schedule(c)
    }

    // Al redimensionar el widget en la pantalla de inicio se vuelve a dibujar (necesario para "Deformar para llenar")
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, newOptions: Bundle) {
        update(c, m, id)
    }

    override fun onEnabled(c: Context) = schedule(c)
    override fun onDisabled(c: Context) { c.getSystemService(AlarmManager::class.java).cancel(tickIntent(c)) }
    override fun onDeleted(c: Context, ids: IntArray) { ids.forEach { Store.unassign(c, it) } }

    override fun onReceive(c: Context, i: Intent) {
        if (i.action == TICK) refreshAll(c) else super.onReceive(c, i)
    }

    companion object {
        const val TICK = "com.example.widgetforge.TICK"
        private const val MAX_PX = 1200f

        private fun tickIntent(c: Context) = PendingIntent.getBroadcast(
            c, 0, Intent(c, WidgetForgeProvider::class.java).setAction(TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun schedule(c: Context) {
            c.getSystemService(AlarmManager::class.java).setRepeating(
                AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 60000, 60000, tickIntent(c)
            )
        }

        fun refreshAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, WidgetForgeProvider::class.java)).forEach { update(c, m, it) }
        }

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            val d = Store.designFor(c, id) ?: return
            val rv = RemoteViews(c.packageName, R.layout.widget_view)

            val bmp = if (d.fit == 1) {
                // Deformar: el dibujo ocupa exactamente el tamaño actual del widget
                val o = m.getAppWidgetOptions(id)
                val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                val dens = c.resources.displayMetrics.density
                val wdp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
                val hdp = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
                if (wdp > 0 && hdp > 0) {
                    val k = minOf(1f, MAX_PX / maxOf(wdp * dens, hdp * dens))
                    Renderer.renderTo(c, d, (wdp * dens * k).toInt(), (hdp * dens * k).toInt())
                } else Renderer.renderFit(c, d, MAX_PX.toInt())
            } else Renderer.renderFit(c, d, MAX_PX.toInt())

            rv.setImageViewBitmap(R.id.img, bmp)
            rv.setOnClickPendingIntent(
                R.id.img, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            m.updateAppWidget(id, rv)
        }
    }
}
