package com.example.widgetforge

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Assets {
    fun dir(c: Context) = File(c.filesDir, "assets").apply { mkdirs() }
    private val bmps = HashMap<String, Bitmap?>()
    private val fonts = HashMap<String, Typeface?>()

    fun bitmap(c: Context, n: String): Bitmap? = bmps.getOrPut(n) {
        val f = File(dir(c), n)
        if (n.isEmpty() || !f.exists()) null else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / s > 1400 || o.outHeight / s > 1400) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }
    }

    fun typeface(c: Context, n: String): Typeface? = fonts.getOrPut(n) {
        runCatching { Typeface.createFromFile(File(dir(c), n)) }.getOrNull()
    }

    fun copyIn(c: Context, uri: Uri, ext: String): String {
        val n = "${UUID.randomUUID()}.$ext"
        c.contentResolver.openInputStream(uri)!!.use { i -> File(dir(c), n).outputStream().use { i.copyTo(it) } }
        return n
    }
}

object Importer {
    // Acepta: .zip/.wforge propio (design.json), .kwgt (preset.json) o .json simple
    fun read(c: Context, uri: Uri): Design? {
        val bytes = c.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        if (bytes.size > 3 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
            val files = LinkedHashMap<String, ByteArray>()
            ZipInputStream(bytes.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) { if (!e.isDirectory) files[e.name] = z.readBytes(); e = z.nextEntry }
            }
            files.entries.firstOrNull { it.key.endsWith("design.json") }?.let { e ->
                files.forEach { (k, v) -> if (k.startsWith("assets/")) File(Assets.dir(c), k.removePrefix("assets/")).writeBytes(v) }
                return Design.from(JSONObject(String(e.value)))
            }
            files.entries.firstOrNull { it.key.endsWith("preset.json") }?.let { e ->
                return Kwgt.convert(c, JSONObject(String(e.value)), files)
            }
            return null
        }
        return Design.from(JSONObject(String(bytes)))
    }

    fun export(c: Context, d: Design, out: OutputStream) {
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("design.json")); z.write(d.toJson().toString().toByteArray()); z.closeEntry()
            d.layers.flatMap { listOf(it.src, it.font) }.filter { it.isNotEmpty() }.toSet().forEach { n ->
                val f = File(Assets.dir(c), n)
                if (f.exists()) { z.putNextEntry(ZipEntry("assets/$n")); z.write(f.readBytes()); z.closeEntry() }
            }
        }
    }
}

// Conversión aproximada de presets KWGT (preset.json). Soporta texto, formas e imágenes;
// el resto de módulos se recorre pero se ignora. Las fórmulas de df()/tf()/bi(level) se evalúan.
object Kwgt {
    private fun num(o: JSONObject, def: Double, vararg k: String): Float {
        for (x in k) if (o.has(x)) return o.optDouble(x, def).toFloat()
        return def.toFloat()
    }
    private fun col(o: JSONObject, k: String, def: Int) = runCatching { Color.parseColor(o.optString(k)) }.getOrDefault(def)

    fun convert(c: Context, root: JSONObject, files: Map<String, ByteArray>): Design {
        val info = root.optJSONObject("preset_info") ?: JSONObject()
        val w = num(info, 400.0, "width").let { if (it > 0) it else 400f }
        val h = num(info, 200.0, "height").let { if (it > 0) it else 200f }
        val d = Design(name = info.optString("title", "KWGT"), w = w, h = h, bg = 0, radius = 0f)
        walk(c, root.optJSONObject("preset_root") ?: JSONObject(), d, files, 0f, 0f, w, h)
        return d
    }

    private fun walk(c: Context, node: JSONObject, d: Design, files: Map<String, ByteArray>, ox: Float, oy: Float, pw: Float, ph: Float) {
        val items = node.optJSONArray("viewgroup_items") ?: return
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val anchor = o.optString("position_anchor", "CENTER")
            val fx = if (anchor.contains("LEFT")) 0f else if (anchor.contains("RIGHT")) 1f else .5f
            val fy = if (anchor.startsWith("TOP")) 0f else if (anchor.startsWith("BOTTOM")) 1f else .5f
            val cx = ox + pw * fx + num(o, 0.0, "position_offset_x")
            val cy = oy + ph * fy + num(o, 0.0, "position_offset_y")
            when (o.optString("internal_type")) {
                "TextModule" -> {
                    val size = num(o, 20.0, "text_size")
                    val raw = o.optString("text_expression", "{hh}:{mm}")
                    val fam = o.optString("text_family", "").substringAfterLast('/')
                    var font = ""
                    files.entries.firstOrNull { fam.isNotEmpty() && (it.key.endsWith("/$fam") || it.key == fam) }?.let { e ->
                        font = "${UUID.randomUUID()}_$fam"; File(Assets.dir(c), font).writeBytes(e.value)
                    }
                    val lines = Vars.resolve(c, raw).split("\n")
                    val pt = Paint().apply { textSize = size; if (font.isNotEmpty()) typeface = Assets.typeface(c, font) }
                    val w = lines.maxOf { pt.measureText(it) }.coerceAtLeast(1f)
                    val fm = pt.fontMetrics
                    val h = (fm.descent - fm.ascent) + size * 1.2f * (lines.size - 1)
                    val stroked = o.optString("paint_style") == "STROKE"
                    val color = col(o, "paint_color", -1)
                    d.layers += Layer(type = "text", text = raw, x = cx - w * fx, y = cy - h * fy - fm.ascent - size, w = w, size = size, font = font,
                        color = if (stroked) 0 else color, stroke = if (stroked) num(o, 1.0, "paint_stroke") else 0f,
                        strokeColor = if (stroked) color else 0x99FFFFFF.toInt(),
                        align = if (fx == 0f) 0 else if (fx == 1f) 2 else 1)
                }
                "ShapeModule" -> {
                    val w = num(o, 100.0, "background_width", "shape_width")
                    val h = num(o, 100.0, "background_height", "shape_height")
                    val sh = o.optString("background_shape", o.optString("shape_shape", "RECT"))
                    val rad = if (sh == "SQUIRCLE") minOf(w, h) * .3f else num(o, 0.0, "background_corners", "shape_corners")
                    d.layers += Layer(type = if (sh == "CIRCLE") "circle" else "rect", x = cx - w * fx, y = cy - h * fy, w = w, h = h,
                        radius = rad, color = col(o, "paint_color", -1))
                }
                "BitmapModule" -> {
                    val fn = o.optString("bitmap_bitmap", "").substringAfterLast('/')
                    val data = files.entries.firstOrNull { fn.isNotEmpty() && (it.key.endsWith("/$fn") || it.key == fn) }?.value
                    if (data != null) {
                        val w = num(o, 100.0, "bitmap_width", "bitmap_size")
                        val h = num(o, 100.0, "bitmap_height", "bitmap_size")
                        val n = "${UUID.randomUUID()}_$fn"
                        File(Assets.dir(c), n).writeBytes(data)
                        d.layers += Layer(type = "image", src = n, x = cx - w * fx, y = cy - h * fy, w = w, h = h, radius = 0f)
                    }
                }
                else -> walk(c, o, d, files, cx - pw / 2, cy - ph / 2, pw, ph)
            }
        }
    }
}
