package com.animevault.app.data.remote

import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.HeaderMap
import retrofit2.http.Streaming
import retrofit2.http.Url
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException

interface GenericApi {
    @Streaming
    @GET
    suspend fun get(@Url url: String, @HeaderMap headers: Map<String, String>): Response<ResponseBody>
}

object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    /** Retrofit se construye con la Base URL que TÚ guardaste en Ajustes. */
    fun api(baseUrl: String): GenericApi =
        Retrofit.Builder().baseUrl(normalizeBase(baseUrl)).client(client).build()
            .create(GenericApi::class.java)

    fun normalizeBase(base: String): String {
        val t = base.trim()
        return if (t.endsWith("/")) t else "$t/"
    }

    fun relative(endpoint: String): String = endpoint.trim().trimStart('/')

    fun authHeaders(key: String): Map<String, String> =
        if (key.isBlank()) emptyMap()
        else mapOf("Authorization" to "Bearer ${key.trim()}", "X-API-Key" to key.trim())

    fun describeError(t: Throwable): String = when (t) {
        is UnknownHostException -> "No se pudo resolver el servidor (revisa la URL o tu internet)"
        is SocketTimeoutException -> "Tiempo de espera agotado"
        is ConnectException -> "No se pudo conectar al servidor"
        is SSLException -> "Error SSL: ${t.message}"
        is IOException -> t.message ?: "Error de red"
        is IllegalArgumentException -> "URL inválida: ${t.message}"
        else -> "${t::class.java.simpleName}: ${t.message}"
    }
}
