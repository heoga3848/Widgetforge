package com.animevault.app.presentation.settings

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.animevault.app.domain.model.AppResult
import com.animevault.app.domain.model.ContentConfig
import com.animevault.app.domain.model.DownloadConfig
import com.animevault.app.domain.usecase.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface TestState {
    data object Idle : TestState
    data object Running : TestState
    data class Done(val ok: Boolean, val message: String) : TestState
}

class SettingsViewModel(
    private val observe: ObserveSettingsUseCase,
    private val save: SaveSettingsUseCase,
    private val testContentUc: TestContentConnectionUseCase,
    private val testDownloadUc: TestDownloadConnectionUseCase
) : ViewModel() {

    var cBase by mutableStateOf("")
    var cKey by mutableStateOf("")
    var cSearch by mutableStateOf("")
    var cDetail by mutableStateOf("")
    var dBase by mutableStateOf("")
    var dKey by mutableStateOf("")
    var dEndpoint by mutableStateOf("")

    var contentSaved by mutableStateOf(false)
    var downloadSaved by mutableStateOf(false)
    var contentTest by mutableStateOf<TestState>(TestState.Idle)
    var downloadTest by mutableStateOf<TestState>(TestState.Idle)

    init {
        viewModelScope.launch {
            val c = observe.content.first()
            cBase = c.baseUrl; cKey = c.apiKey; cSearch = c.searchEndpoint; cDetail = c.detailEndpoint
            val d = observe.download.first()
            dBase = d.baseUrl; dKey = d.apiKey; dEndpoint = d.downloadEndpoint
        }
    }

    private fun contentConfig() = ContentConfig(cBase.trim(), cKey.trim(), cSearch.trim(), cDetail.trim())
    private fun downloadConfig() = DownloadConfig(dBase.trim(), dKey.trim(), dEndpoint.trim())

    fun saveContent() {
        viewModelScope.launch {
            save.content(contentConfig())
            contentSaved = true; delay(2500); contentSaved = false
        }
    }

    fun saveDownload() {
        viewModelScope.launch {
            save.download(downloadConfig())
            downloadSaved = true; delay(2500); downloadSaved = false
        }
    }

    fun testContent() {
        viewModelScope.launch {
            contentTest = TestState.Running
            contentTest = when (val r = testContentUc(contentConfig())) {
                is AppResult.Success -> TestState.Done(true, r.data)
                is AppResult.Error -> TestState.Done(false, "❌ ${r.message}")
                AppResult.NotConfigured -> TestState.Done(false, "❌ Faltan campos")
            }
        }
    }

    fun testDownload() {
        viewModelScope.launch {
            downloadTest = TestState.Running
            downloadTest = when (val r = testDownloadUc(downloadConfig())) {
                is AppResult.Success -> TestState.Done(true, r.data)
                is AppResult.Error -> TestState.Done(false, "❌ ${r.message}")
                AppResult.NotConfigured -> TestState.Done(false, "❌ Faltan campos")
            }
        }
    }
}
