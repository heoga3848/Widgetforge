package com.example.widgetforge

import android.content.Context
import android.graphics.*
import java.util.Calendar

object Renderer {
    /** Render a tamaño de diseño * scale, con la deformación global (sx, sy) del diseño aplicada. */
    fun render(c: Context, d: Design, scale: Float = 2f): Bitmap {
        val bmp = Bitmap.createBitmap(
            (d.w * d.sx * scale).toInt().coerceAtLeast(1), (d.h * d.sy * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888
        )
        val cv = Canvas(bmp)
        cv.scale(d.sx, d.sy)
        drawDesign(c, cv, d, scale)
        return bmp
    }

    /** Render con el lado mayor limitado a [maxPx] (para vistas previas y widgets). */
    fun renderFit(c: Context, d: Design, maxPx: Int): Bitmap =
        render(c, d, (maxPx / maxOf(d.outW, d.outH, 1f)).coerceAtMost(2f))

    /**
     * Render a un tamaño de píxeles exacto (el del widget en la pantalla de inicio).
     * fit == 1: el diseño se deforma para llenar todo el widget. Si no, se ajusta manteniendo proporción y centrado.
     */
    fun renderTo(c: Context, d: Design, outW: Int, outH: Int): Bitmap {
        val ow = outW.coerceAtLeast(1)
        val oh = outH.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        if (d.fit == 1) {
            cv.scale(ow / d.w, oh / d.h)
        } else {
            val k = minOf(ow / d.outW, oh / d.outH)
            cv.translate((ow - d.outW * k) / 2f, (oh - d.outH * k) / 2f)
            cv.scale(k * d.sx, k * d.sy)
        }
        drawDesign(c, cv, d, 1f)
        return bmp
    }

    private fun drawDesign(c: Context, cv: Canvas, d: Design, s: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = d.bg
        cv.drawRoundRect(RectF(0f, 0f, d.w * s, d.h * s), d.radius * s, d.radius * s, p)
        for (l in d.layers) { cv.save(); draw(c, cv, l, s, d.globals); cv.restore() }
    }

    private fun style(p: Paint, l: Layer, s: Float, r: RectF) {
        p.reset(); p.isAntiAlias = true; p.color = l.color
        if (l.grad) p.shader = LinearGradient(r.left, r.top, r.left, r.top + maxOf(r.height(), 1f), l.color, l.color2, Shader.TileMode.CLAMP)
        if (l.shadow > 0) p.setShadowLayer(l.shadow * s, 0f, l.shadow * s / 3, l.shColor)
    }

    private fun strokeStyle(p: Paint, l: Layer, s: Float) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = l.stroke * s; p.color = l.strokeColor
    }

    private fun shape(cv: Canvas, l: Layer, r: RectF, s: Float, p: Paint) {
        when (l.type) {
            "circle" -> cv.drawOval(r, p)
            "triangle" -> cv.drawPath(Path().apply {
                moveTo(r.centerX(), r.top); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close()
            }, p)
            else -> cv.drawRoundRect(r, l.radius * s, l.radius * s, p)
        }
    }

    private class TextInfo(val lines: List<String>, val rect: RectF, val tf: Typeface?)

    private fun textInfo(c: Context, l: Layer, s: Float, gl: Map<String, String>): TextInfo {
        var t = Vars.resolve(c, l.text, gl)
        t = when (l.textCase) {
            1 -> t.uppercase()
            2 -> t.lowercase()
            3 -> t.split(" ").joinToString(" ") { w -> w.replaceFirstChar { ch -> ch.uppercase() } }
            else -> t
        }
        val lines = t.split("\n")
        val tf = if (l.font.isNotEmpty()) Assets.typeface(c, l.font) else null
        val lh = l.size * s * 1.2f
        val r = RectF(l.x * s, l.y * s, (l.x + l.w) * s, l.y * s + lh * lines.size)
        return TextInfo(lines, r, tf)
    }

    private fun draw(c: Context, cv: Canvas, l: Layer, s: Float, gl: Map<String, String>) {
        val p = Paint()
        val ti = if (l.type == "text") textInfo(c, l, s, gl) else null
        val r = ti?.rect ?: RectF(l.x * s, l.y * s, (l.x + l.w) * s, (l.y + l.h) * s)

        // Transformaciones de la capa alrededor de su centro: rotar, estirar (ancho/alto) e inclinar
        if (l.rot != 0f || l.sx != 1f || l.sy != 1f || l.skew != 0f) {
            val cx = r.centerX(); val cy = r.centerY()
            cv.translate(cx, cy)
            if (l.rot != 0f) cv.rotate(l.rot)
            if (l.sx != 1f || l.sy != 1f) cv.scale(l.sx, l.sy)
            if (l.skew != 0f) cv.skew(Math.tan(Math.toRadians(l.skew.toDouble())).toFloat(), 0f)
            cv.translate(-cx, -cy)
        }

        when (l.type) {
            "text" -> if (ti != null) text(cv, p, l, s, ti)
            "rect", "circle", "triangle" -> {
                style(p, l, s, r); shape(cv, l, r, s, p)
                if (l.stroke > 0) { strokeStyle(p, l, s); shape(cv, l, r, s, p) }
            }
            "image" -> Assets.bitmap(c, l.src)?.let { b ->
                cv.clipPath(Path().apply { addRoundRect(r, l.radius * s, l.radius * s, Path.Direction.CW) })
                val sc = maxOf(r.width() / b.width, r.height() / b.height)
                val sw = r.width() / sc; val sh = r.height() / sc
                val src = Rect(((b.width - sw) / 2).toInt(), ((b.height - sh) / 2).toInt(), ((b.width + sw) / 2).toInt(), ((b.height + sh) / 2).toInt())
                p.isAntiAlias = true; p.isFilterBitmap = true; p.alpha = l.color ushr 24
                cv.drawBitmap(b, src, r, p)
                if (l.stroke > 0) { strokeStyle(p, l, s); cv.drawRoundRect(r, l.radius * s, l.radius * s, p) }
            }
            "arc" -> {
                p.isAntiAlias = true; p.color = l.color
                p.style = Paint.Style.STROKE; p.strokeWidth = l.size * s; p.strokeCap = Paint.Cap.ROUND
                val i = l.size * s / 2; r.inset(i, i)
                val base = l.color ushr 24
                p.alpha = base / 5; cv.drawArc(r, 0f, 360f, false, p)
                p.alpha = base; cv.drawArc(r, -90f, 360f * Vars.progress(c, l.progress, gl), false, p)
            }
            "bar" -> {
                val rr = minOf(l.radius * s, r.height() / 2f)
                val base = l.color ushr 24
                p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = l.color
                p.alpha = base / 5; cv.drawRoundRect(r, rr, rr, p)
                p.alpha = base
                cv.save()
                cv.clipPath(Path().apply { addRoundRect(r, rr, rr, Path.Direction.CW) })
                cv.drawRect(r.left, r.top, r.left + r.width() * Vars.progress(c, l.progress, gl), r.bottom, p)
                cv.restore()
            }
            "calendar" -> calendar(cv, p, l, s, r)
        }
    }

    private fun calendar(cv: Canvas, p: Paint, l: Layer, s: Float, r: RectF) {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val first = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val cw = r.width() / 7; val ch = r.height() / 7
        p.reset(); p.isAntiAlias = true; p.textSize = l.size * s; p.textAlign = Paint.Align.CENTER
        val ty = p.textSize / 3
        p.color = l.color; p.alpha = (p.alpha * 0.6f).toInt()
        val hdr = "MTWTFSS"
        for (i in 0 until 7) cv.drawText(hdr[i].toString(), r.left + cw * (i + .5f), r.top + ch * .5f + ty, p)
        for (d in 1..days) {
            val idx = first + d - 1
            val cx = r.left + cw * (idx % 7 + .5f); val cy = r.top + ch * (idx / 7 + 1.5f)
            if (d == today) { p.color = l.color2; cv.drawCircle(cx, cy, minOf(cw, ch) * .45f, p) }
            p.color = if (d == today) -1 else l.color
            cv.drawText(d.toString(), cx, cy + ty, p)
        }
    }

    private fun text(cv: Canvas, p: Paint, l: Layer, s: Float, ti: TextInfo) {
        val r = ti.rect
        val lh = l.size * s * 1.2f
        val bw = l.w * s
        val ax = when (l.align) { 1 -> r.left + bw / 2; 2 -> r.left + bw; else -> r.left }
        val al = when (l.align) { 1 -> Paint.Align.CENTER; 2 -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
        val g = RectF(r.left, r.top, r.left + maxOf(bw, 1f), r.top + lh * ti.lines.size)
        fun base() { p.textSize = l.size * s; p.typeface = ti.tf; p.textAlign = al; p.isFakeBoldText = l.bold }
        for ((i, t) in ti.lines.withIndex()) {
            val y = r.top + l.size * s + lh * i
            if (l.stroke > 0) { strokeStyle(p, l, s); base(); cv.drawText(t, ax, y, p) }
            style(p, l, s, g); base(); cv.drawText(t, ax, y, p)
        }
    }
}
