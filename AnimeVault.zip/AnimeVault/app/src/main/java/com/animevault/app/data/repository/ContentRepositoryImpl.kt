package com.animevault.app.data.repository

import android.net.Uri
import com.animevault.app.data.remote.AnimeJsonMapper
import com.animevault.app.data.remote.Http
import com.animevault.app.domain.model.*
import com.animevault.app.domain.repository.ContentRepository
import com.animevault.app.domain.repository.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class ContentRepositoryImpl(private val settings: SettingsRepository) : ContentRepository {

    override suspend fun search(query: String): AppResult<List<Anime>> {
        val cfg = settings.contentConfig.first()
        if (!cfg.isConfigured) return AppResult.NotConfigured
        val r = request(cfg, searchEndpoint(cfg, query))
        if (r is AppResult.Error) return AppResult.Error(r.message)
        if (r !is AppResult.Success) return AppResult.NotConfigured
        val list: List<Anime> = try {
            AnimeJsonMapper.parseList(r.data)
        } catch (e: Exception) {
            return AppResult.Error("La respuesta no es un JSON válido:\n${r.data.take(300)}")
        }
        return AppResult.Success(list)
    }

    override suspend fun detail(id: String): AppResult<Anime> {
        val cfg = settings.contentConfig.first()
        if (!cfg.isConfigured) return AppResult.NotConfigured
        val ep = cfg.detailEndpoint.replace("{id}", Uri.encode(id))
        val r = request(cfg, ep)
        if (r is AppResult.Error) return AppResult.Error(r.message)
        if (r !is AppResult.Success) return AppResult.NotConfigured
        val anime: Anime? = runCatching { AnimeJsonMapper.parseDetail(r.data, id) }.getOrNull()
        if (anime == null) {
            return AppResult.Error("La API respondió, pero no pude encontrar el título/datos del anime:\n${r.data.take(300)}")
        }
        return AppResult.Success(anime)
    }

    override suspend fun testConnection(config: ContentConfig): AppResult<String> {
        if (config.baseUrl.isBlank() || config.searchEndpoint.isBlank())
            return AppResult.Error("Completa la Base URL y el endpoint de búsqueda")
        val r = request(config, searchEndpoint(config, "naruto"))
        if (r is AppResult.Error) return AppResult.Error(r.message)
        if (r !is AppResult.Success) return AppResult.Error("Faltan campos")
        val n: Int? = runCatching { AnimeJsonMapper.parseList(r.data).size }.getOrNull()
        if (n == null) return AppResult.Error("Responde, pero no devuelve JSON válido:\n${r.data.take(200)}")
        return AppResult.Success("✅ Conexión correcta. Resultados reconocidos: $n")
    }

    private fun searchEndpoint(cfg: ContentConfig, query: String): String {
        val q = Uri.encode(query.trim())
        return if (cfg.searchEndpoint.contains("{q}")) cfg.searchEndpoint.replace("{q}", q)
        else cfg.searchEndpoint + q
    }

    private suspend fun request(cfg: ContentConfig, endpoint: String): AppResult<String> =
        withContext(Dispatchers.IO) {
            try {
                val resp = Http.api(cfg.baseUrl).get(Http.relative(endpoint), Http.authHeaders(cfg.apiKey))
                if (resp.isSuccessful) {
                    AppResult.Success(resp.body()?.string().orEmpty())
                } else {
                    val body = resp.errorBody()?.string().orEmpty().take(300)
                    AppResult.Error("HTTP ${resp.code()} ${resp.message()}\n$body")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppResult.Error(Http.describeError(e))
            }
        }
}
