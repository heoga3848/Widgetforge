package com.example.widgetforge

import android.content.Context
import android.graphics.*
import java.util.Calendar

object Renderer {
    fun render(c: Context, d: Design, scale: Float = 2f): Bitmap {
        val bmp = Bitmap.createBitmap((d.w * scale).toInt().coerceAtLeast(1), (d.h * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = d.bg
        cv.drawRoundRect(RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()), d.radius * scale, d.radius * scale, p)
        for (l in d.layers) { cv.save(); draw(c, cv, l, scale); cv.restore() }
        return bmp
    }

    private fun style(p: Paint, l: Layer, s: Float, r: RectF) {
        p.reset(); p.isAntiAlias = true; p.color = l.color
        if (l.grad) p.shader = LinearGradient(r.left, r.top, r.left, r.top + maxOf(r.height(), 1f), l.color, l.color2, Shader.TileMode.CLAMP)
        if (l.shadow > 0) p.setShadowLayer(l.shadow * s, 0f, l.shadow * s / 3, l.shColor)
    }

    private fun strokeStyle(p: Paint, l: Layer, s: Float) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = l.stroke * s; p.color = l.strokeColor
    }

    private fun shape(cv: Canvas, l: Layer, r: RectF, s: Float, p: Paint) {
        if (l.type == "circle") cv.drawOval(r, p) else cv.drawRoundRect(r, l.radius * s, l.radius * s, p)
    }

    private fun draw(c: Context, cv: Canvas, l: Layer, s: Float) {
        val p = Paint()
        val r = RectF(l.x * s, l.y * s, (l.x + l.w) * s, (l.y + l.h) * s)
        if (l.rot != 0f) cv.rotate(l.rot, r.centerX(), r.centerY())
        when (l.type) {
            "text" -> text(c, cv, p, l, s, r)
            "rect", "circle" -> {
                style(p, l, s, r); shape(cv, l, r, s, p)
                if (l.stroke > 0) { strokeStyle(p, l, s); shape(cv, l, r, s, p) }
            }
            "image" -> Assets.bitmap(c, l.src)?.let { b ->
                cv.clipPath(Path().apply { addRoundRect(r, l.radius * s, l.radius * s, Path.Direction.CW) })
                val sc = maxOf(r.width() / b.width, r.height() / b.height)
                val sw = r.width() / sc; val sh = r.height() / sc
                val src = Rect(((b.width - sw) / 2).toInt(), ((b.height - sh) / 2).toInt(), ((b.width + sw) / 2).toInt(), ((b.height + sh) / 2).toInt())
                p.isAntiAlias = true; p.isFilterBitmap = true; p.alpha = l.color ushr 24
                cv.drawBitmap(b, src, r, p)
                if (l.stroke > 0) { strokeStyle(p, l, s); cv.drawRoundRect(r, l.radius * s, l.radius * s, p) }
            }
            "arc" -> {
                p.isAntiAlias = true; p.color = l.color
                p.style = Paint.Style.STROKE; p.strokeWidth = l.size * s; p.strokeCap = Paint.Cap.ROUND
                val i = l.size * s / 2; r.inset(i, i)
                p.alpha = 50; cv.drawArc(r, 0f, 360f, false, p)
                p.alpha = 255; cv.drawArc(r, -90f, 360f * Vars.num(c, l.progress), false, p)
            }
            "calendar" -> calendar(cv, p, l, s, r)
        }
    }

    private fun calendar(cv: Canvas, p: Paint, l: Layer, s: Float, r: RectF) {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val first = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val cw = r.width() / 7; val ch = r.height() / 7
        p.reset(); p.isAntiAlias = true; p.textSize = l.size * s; p.textAlign = Paint.Align.CENTER
        val ty = p.textSize / 3
        p.color = l.color; p.alpha = (p.alpha * 0.6f).toInt()
        val hdr = "MTWTFSS"
        for (i in 0 until 7) cv.drawText(hdr[i].toString(), r.left + cw * (i + .5f), r.top + ch * .5f + ty, p)
        for (d in 1..days) {
            val idx = first + d - 1
            val cx = r.left + cw * (idx % 7 + .5f); val cy = r.top + ch * (idx / 7 + 1.5f)
            if (d == today) { p.color = l.color2; cv.drawCircle(cx, cy, minOf(cw, ch) * .45f, p) }
            p.color = if (d == today) -1 else l.color
            cv.drawText(d.toString(), cx, cy + ty, p)
        }
    }

    private fun text(c: Context, cv: Canvas, p: Paint, l: Layer, s: Float, r: RectF) {
        val lines = Vars.resolve(c, l.text).split("\n")
        val lh = l.size * s * 1.2f
        val tf = if (l.font.isNotEmpty()) Assets.typeface(c, l.font) else null
        val bw = l.w * s
        val ax = when (l.align) { 1 -> r.left + bw / 2; 2 -> r.left + bw; else -> r.left }
        val al = when (l.align) { 1 -> Paint.Align.CENTER; 2 -> Paint.Align.RIGHT; else -> Paint.Align.LEFT }
        val g = RectF(r.left, r.top, r.left + maxOf(bw, 1f), r.top + lh * lines.size)
        fun base() { p.textSize = l.size * s; p.typeface = tf; p.textAlign = al; p.isFakeBoldText = l.bold }
        for ((i, t) in lines.withIndex()) {
            val y = r.top + l.size * s + lh * i
            if (l.stroke > 0) { strokeStyle(p, l, s); base(); cv.drawText(t, ax, y, p) }
            style(p, l, s, g); base(); cv.drawText(t, ax, y, p)
        }
    }
}
