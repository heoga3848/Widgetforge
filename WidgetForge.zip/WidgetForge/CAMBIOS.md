# Cambios

## Deformar / redimensionar
- Tamaño del widget con campos numéricos (ancho/alto) + opción de escalar el contenido al cambiar el tamaño.
- Deformar todo el widget: estirar ancho y alto por separado (o con proporción bloqueada).
- En la pantalla de inicio: "Ajustar (proporcional)" o "Deformar para llenar" (se redibuja al redimensionar el widget).
- Por capa: estirar ancho/alto, inclinación, rotación, centrar, llenar lienzo, números exactos X/Y/ancho/alto.
- Capas nuevas: triángulo y barra de progreso. Texto: MAYÚS / minús / Título.

## Importar KWGT
- Acepta .kwgt/.klwp/.klck, preset.json suelto, zips con varios presets o .kwgt anidados.
- Módulos: texto, forma (rect, círculo, óvalo, triángulo, squircle), imagen, progreso, grupos Overlap/Stack anidados.
- Fórmulas Kustom: df tf bi mu tc if gv, operadores, comparaciones, texto entre comillas (Formula.kt).
- Widgets bloqueados (locked) se detectan y se rechazan con un mensaje claro en vez de importarse vacíos.
- Informe de importación: módulos omitidos, fórmulas sin soporte, valores dinámicos fijados, propiedades ignoradas.
