package com.animevault.app.data.repository

import android.content.Context
import androidx.work.*
import com.animevault.app.data.download.DownloadWorker
import com.animevault.app.data.local.db.DownloadDao
import com.animevault.app.data.local.db.DownloadEntity
import com.animevault.app.data.local.db.toDomain
import com.animevault.app.data.remote.Http
import com.animevault.app.domain.model.*
import com.animevault.app.domain.repository.DownloadRepository
import com.animevault.app.domain.repository.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

class DownloadRepositoryImpl(
    private val context: Context,
    private val dao: DownloadDao,
    private val settings: SettingsRepository
) : DownloadRepository {

    private val wm get() = WorkManager.getInstance(context)

    override fun observeAll(): Flow<List<DownloadItem>> = dao.observeAll().map { l -> l.map { it.toDomain() } }

    override suspend fun enqueue(animeId: String, title: String): AppResult<Unit> {
        if (!settings.downloadConfig.first().isConfigured) return AppResult.NotConfigured
        val existing = dao.findByAnime(animeId)
        if (existing != null) {
            return if (existing.state == "FAILED") {
                resume(existing.id); AppResult.Success(Unit)
            } else AppResult.Error("Ya está en tu lista de descargas")
        }
        val id = dao.insert(DownloadEntity(animeId = animeId, title = title, state = "QUEUED"))
        schedule(id)
        return AppResult.Success(Unit)
    }

    override suspend fun pause(id: Long) {
        dao.transition(id, "PAUSED", listOf("QUEUED", "RUNNING"))
        wm.cancelUniqueWork("download_$id")
    }

    override suspend fun resume(id: Long) {
        if (dao.transition(id, "QUEUED", listOf("PAUSED", "FAILED")) > 0) schedule(id)
    }

    override suspend fun remove(id: Long) {
        wm.cancelUniqueWork("download_$id")
        val e = dao.get(id)
        e?.filePath?.let { runCatching { File(it).delete() } }
        dao.delete(id)
    }

    private fun schedule(id: Long) {
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(workDataOf(DownloadWorker.KEY_ID to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniqueWork("download_$id", ExistingWorkPolicy.REPLACE, req)
    }

    override suspend fun testConnection(config: DownloadConfig): AppResult<String> = withContext(Dispatchers.IO) {
        if (config.baseUrl.isBlank() || config.downloadEndpoint.isBlank())
            return@withContext AppResult.Error("Completa la Base URL y el endpoint de descarga")
        try {
            val ep = config.downloadEndpoint.replace("{id}", "1").replace("{title}", "test")
            val headers = Http.authHeaders(config.apiKey) + ("Range" to "bytes=0-0")
            val resp = Http.api(config.baseUrl).get(Http.relative(ep), headers)
            val code = resp.code()
            resp.body()?.close()
            resp.errorBody()?.close()
            when {
                code in 200..299 -> AppResult.Success("✅ El servidor responde (HTTP $code).")
                code == 401 || code == 403 -> AppResult.Error("HTTP $code: el servidor rechazó la API Key / acceso")
                code in 400..499 -> AppResult.Success("⚠️ El servidor responde (HTTP $code) con un id de prueba. Es normal si el id \"1\" no existe.")
                else -> AppResult.Error("HTTP $code: error del servidor")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppResult.Error(Http.describeError(e))
        }
    }
}
