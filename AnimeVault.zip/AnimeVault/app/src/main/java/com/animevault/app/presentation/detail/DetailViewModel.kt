package com.animevault.app.presentation.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.animevault.app.domain.model.*
import com.animevault.app.domain.usecase.DownloadUseCases
import com.animevault.app.domain.usecase.GetAnimeDetailUseCase
import com.animevault.app.domain.usecase.MyListUseCases
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface DetailUiState {
    data object Loading : DetailUiState
    data object NotConfigured : DetailUiState
    data class Error(val message: String) : DetailUiState
    data class Success(val anime: Anime) : DetailUiState
}

data class UiMessage(val text: String, val goSettings: Boolean = false)

class DetailViewModel(
    private val id: String,
    private val getDetail: GetAnimeDetailUseCase,
    private val myList: MyListUseCases,
    private val downloads: DownloadUseCases
) : ViewModel() {

    private val _state = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val state: StateFlow<DetailUiState> = _state.asStateFlow()

    val entry: StateFlow<ListEntry?> = myList.observe(id)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 4)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = DetailUiState.Loading
            _state.value = when (val r = getDetail(id)) {
                is AppResult.Success -> DetailUiState.Success(r.data)
                is AppResult.Error -> DetailUiState.Error(r.message)
                AppResult.NotConfigured -> DetailUiState.NotConfigured
            }
        }
    }

    private fun current(): Anime? = (_state.value as? DetailUiState.Success)?.anime

    fun setStatus(status: ListStatus?) {
        val a = current() ?: return
        viewModelScope.launch { myList.setStatus(a, status) }
    }

    fun toggleFavorite() {
        val a = current() ?: return
        viewModelScope.launch { myList.toggleFavorite(a) }
    }

    fun download() {
        val a = current() ?: return
        viewModelScope.launch {
            when (val r = downloads.enqueue(a.id, a.title)) {
                is AppResult.Success -> _messages.emit(UiMessage("Descarga iniciada. Mira la pestaña Descargas"))
                is AppResult.Error -> _messages.emit(UiMessage(r.message))
                AppResult.NotConfigured -> _messages.emit(UiMessage("Configura tu API de Descargas en Ajustes", true))
            }
        }
    }
}
